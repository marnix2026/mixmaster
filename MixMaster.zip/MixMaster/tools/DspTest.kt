import mg.mixmaster.*
import kotlin.math.*
import java.util.Random

fun synthVocal(sec: Double): Stereo {
    val n = (sec * SR).toInt()
    val l = FloatArray(n + SR * 4); val r = FloatArray(n + SR * 4)
    val rnd = Random(1)
    val sib = Biquad.bandpass(7000.0, 1.0)
    var ph = 0.0
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val syl = (sin(2 * PI * 2.2 * t) * 0.5 + 0.5).pow(1.5)          // syllabes
        val f0 = 220.0 + 40 * sin(2 * PI * 0.5 * t)
        ph += 2 * PI * f0 / SR
        var v = 0.0
        for (h in 1..12) v += sin(ph * h) / h * (if (h in 3..5) 1.5 else 1.0)
        v *= syl * 0.25
        // "s" bursts every 1.5 s, 120 ms
        val tm = t % 1.5
        val s = if (tm < 0.12) sib.process((rnd.nextFloat() - 0.5f) * 1.2f).toDouble() else 0.0
        val x = (v + s).toFloat()
        l[i] = x; r[i] = x
    }
    return Stereo(l, r, n)
}

fun synthInst(sec: Double): Stereo {
    val n = (sec * SR).toInt()
    val l = FloatArray(n + SR * 4); val r = FloatArray(n + SR * 4)
    val rnd = Random(2)
    var bph = 0.0
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val beat = t % 0.5
        val kick = exp(-beat * 18) * sin(2 * PI * (50 + 80 * exp(-beat * 40)) * beat) * 0.8
        bph += 2 * PI * 55.0 / SR
        val bass = sin(bph) * 0.35 * (0.6 + 0.4 * exp(-beat * 4))
        val chord = (sin(2 * PI * 261.6 * t) + sin(2 * PI * 329.6 * t) + sin(2 * PI * 392.0 * t)) * 0.08
        val hat = if ((t % 0.25) < 0.03) (rnd.nextFloat() - 0.5) * 0.3 * exp(-(t % 0.25) * 90) else 0.0
        l[i] = (kick + bass + chord + hat).toFloat()
        r[i] = (kick + bass + chord * 0.8 + hat * 1.2).toFloat()
    }
    return Stereo(l, r, n)
}

fun check(name: String, s: Stereo, rep: MixReport, t0: Long) {
    var nan = 0
    for (i in 0 until s.n) if (s.l[i].isNaN() || s.r[i].isNaN() || s.l[i].isInfinite() || s.r[i].isInfinite()) nan++
    val ms = System.currentTimeMillis() - t0
    println("[$name] frames=${s.n} (${"%.1f".format(s.n.toDouble() / SR)} s) LUFS=${"%.2f".format(rep.lufs)} peak=${"%.2f".format(rep.peakDb)} dBFS NaN/Inf=$nan time=${ms}ms")
}

fun bestLag(a: FloatArray, b: FloatArray, n: Int, maxLag: Int): Int {
    // correlation of a (original, mono) with b (processed) using a 5 s window in the middle
    val st = SR * 2; val len = SR * 4
    var best = 0; var bv = -1e30
    for (lag in -maxLag..maxLag) {
        var c = 0.0
        var i = 0
        while (i < len) { c += a[st + i].toDouble() * b[st + i + lag]; i++ }
        if (c > bv) { bv = c; best = lag }
    }
    return best
}

fun main() {
    val sec = 30.0
    // ---------- Fomba mitambatra ----------
    run {
        val v = synthVocal(sec); val inst = synthInst(sec)
        val mix = Stereo(FloatArray(v.l.size), FloatArray(v.l.size), v.n)
        for (i in 0 until v.n) { mix.l[i] = inst.l[i] + v.l[i]; mix.r[i] = inst.r[i] + v.r[i] }
        val orig = mix.l.copyOf()
        val inLufs = Loudness.measure(mix.l, mix.r, mix.n)
        println("Merged input LUFS=${"%.2f".format(inLufs)} peak=${"%.2f".format(Loudness.peakDb(mix.l, mix.r, mix.n))}")
        for (target in listOf(-14.0, -11.0, -9.0)) {
            val m = Stereo(mix.l.copyOf(), mix.r.copyOf(), mix.n)
            val t0 = System.currentTimeMillis()
            val (out, rep) = Mixer.processMerged(m, MixSettings(0.0, 0.0, 0.4f, 0.0, target)) { _, _ -> }
            check("merged target=$target", out, rep, t0)
            if (target == -11.0) println("   lag(original->processed) = ${bestLag(orig, out.l, out.n, 400)} samples")
        }
    }
    // ---------- Fomba stems ----------
    run {
        val v = synthVocal(sec); val inst = synthInst(sec)
        val t0 = System.currentTimeMillis()
        val (out, rep) = Mixer.process(v, inst, MixSettings(0.0, 0.0, 0.4f, 0.0, -11.0)) { _, _ -> }
        check("stems target=-11", out, rep, t0)
    }
    // ---------- Limiter: tsy tokony hihoatra ny ceiling ----------
    run {
        val n = SR * 5
        val s = Stereo(FloatArray(n) { (sin(it * 0.05) * 3.0).toFloat() }, FloatArray(n) { (sin(it * 0.031) * 4.0).toFloat() }, n)
        Limiter.process(s, -1.0)
        println("[limiter] peak after = ${"%.3f".format(Loudness.peakDb(s.l, s.r, s.n))} dBFS (ceiling -1.0)")
    }
    // ---------- Fahanginana / hira fohy ----------
    run {
        val s = Stereo(FloatArray(SR * 2), FloatArray(SR * 2), SR / 2)
        val (out, rep) = Mixer.processMerged(s, MixSettings(0.0, 0.0, 0.4f, 0.0, -11.0)) { _, _ -> }
        println("[silence] LUFS=${rep.lufs} peak=${rep.peakDb} n=${out.n}")
    }
}
