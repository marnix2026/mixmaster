package mg.mixmaster

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.exp

class MixSettings(
    val vocalDb: Double,       // -12..+12 dB
    val instDb: Double,        // -12..+12 dB
    val reverb: Float,         // 0..1
    val offsetMs: Double,      // -300..+300 ms (tsy mety ho latsaka noho 0 ny feo)
    val targetLufs: Double     // -14 / -11 / -9
)

class MixReport(val lufs: Double, val peakDb: Double, val seconds: Double)

/** Ny feo sy ny mozika dia avadika "pre-processing" izay lasa mixing, avy eo mastering. */
object Mixer {

    private const val WORK_LUFS = -20.0
    private const val VOCAL_REL_LU = -2.0   // toerana mahazatra amin'ny mozika

    /** Mamerina ny feo vita; ny arrays an'ny [inst] dia ampiasaina indray. */
    fun process(
        voc: Stereo,
        inst: Stereo,
        s: MixSettings,
        report: (Int, String) -> Unit
    ): Pair<Stereo, MixReport> {

        // ---------------- 1. Chain ny feo ----------------
        report(5, "Manadio ny feo (EQ)...")
        EqChain {
            listOf(
                Biquad.highpass(80.0),
                Biquad.peaking(300.0, 1.0, -2.0),
                Biquad.peaking(3500.0, 0.9, 2.0),
                Biquad.highShelf(10000.0, 2.0)
            )
        }.process(voc)

        report(12, "Mampihena ny \"s\" (de-esser)...")
        DeEsser().process(voc)

        report(18, "Compressor ny feo...")
        // Alohan'ny compressor: asio ho -20 LUFS mba hifanaraka ny threshold
        scale(voc, (WORK_LUFS - Loudness.measure(voc.l, voc.r, voc.n)).let { dbToLin(it).toFloat() })
        Compressor(thrDb = -22.0, ratio = 3.5, attackMs = 8.0, releaseMs = 120.0, kneeDb = 8.0).process(voc)

        // ---------------- 2. Chain ny mozika ----------------
        report(30, "Manadio ny mozika (EQ)...")
        EqChain {
            listOf(
                Biquad.highpass(25.0),
                Biquad.peaking(2800.0, 0.8, -1.5)   // mamela toerana ho an'ny feo
            )
        }.process(inst)

        // ---------------- 3. Fandanjalanjana ----------------
        report(40, "Mandanjalanja ny haavon'ny feo sy mozika...")
        val vocLufs = Loudness.measure(voc.l, voc.r, voc.n)
        val instLufs = Loudness.measure(inst.l, inst.r, inst.n)
        val vocTarget = WORK_LUFS + VOCAL_REL_LU + s.vocalDb
        val instTarget = WORK_LUFS + s.instDb
        val vg = dbToLin(vocTarget - vocLufs).toFloat()
        val ig = dbToLin(instTarget - instLufs).toFloat()

        // ---------------- 4. Mixing ----------------
        report(48, "Mamangaro feo + mozika sy reverb...")
        val off = (s.offsetMs * SR / 1000.0).roundToInt().coerceAtLeast(0)
        val tail = if (s.reverb > 0f) (SR * 2.5).toInt() else 0
        val total = max(inst.n, voc.n + off) + tail
        val mix: Stereo = if (inst.l.size >= total) inst else
            Stereo(inst.l.copyOf(total), inst.r.copyOf(total), inst.n)
        val oldN = inst.n

        val reverb = Reverb()
        val sendHp = Biquad.highpass(250.0)
        val sendLp = Biquad.lowpass(9000.0)
        val preDelay = FloatArray((SR * 0.020).toInt())
        var pi = 0
        val rg = s.reverb * 0.6f

        // ducking: mampihena kely ny mozika rehefa misy feo
        val ref = dbToLin(vocTarget).toFloat() * 2f
        val refInv = 1f / ref
        val duckDepth = 0.2f
        val ac = exp(-1.0 / (0.005 * SR)).toFloat()
        val rc = exp(-1.0 / (0.200 * SR)).toFloat()
        var env = 0f

        for (i in 0 until total) {
            val j = i - off
            var vl = 0f
            var vr = 0f
            if (j >= 0 && j < voc.n) {
                vl = voc.l[j] * vg
                vr = voc.r[j] * vg
            }
            val a = max(abs(vl), abs(vr))
            env = if (a > env) ac * env + (1 - ac) * a else rc * env + (1 - rc) * a
            val dg = 1f - duckDepth * min(1f, env * refInv)

            var l = (if (i < oldN) mix.l[i] else 0f) * ig * dg + vl
            var r = (if (i < oldN) mix.r[i] else 0f) * ig * dg + vr

            if (rg > 0f) {
                var send = (vl + vr) * 0.5f
                send = sendLp.process(sendHp.process(send))
                val d = preDelay[pi]
                preDelay[pi] = send
                if (++pi >= preDelay.size) pi = 0
                reverb.process(d)
                l += reverb.outL * rg
                r += reverb.outR * rg
            }
            mix.l[i] = l
            mix.r[i] = r
        }
        mix.n = total
        voc.l = FloatArray(0); voc.r = FloatArray(0); voc.n = 0

        // ---------------- 5. Mastering ----------------
        report(62, "Mastering: EQ...")
        EqChain {
            listOf(
                Biquad.highpass(28.0),
                Biquad.lowShelf(100.0, 1.0),
                Biquad.peaking(250.0, 1.0, -1.0),
                Biquad.highShelf(9000.0, 1.5)
            )
        }.process(mix)

        report(70, "Mastering: glue compressor...")
        val mixLufs = Loudness.measure(mix.l, mix.r, mix.n)
        Compressor(thrDb = mixLufs + 2.0, ratio = 2.0, attackMs = 30.0, releaseMs = 180.0, kneeDb = 6.0).process(mix)

        return Pair(mix, finish(mix, s.targetLufs, report))
    }

    /** Haavon'ny feo (LUFS) + limiter. Mamerina tatitra mba hanakaiky ny tanjona. */
    private fun finish(mix: Stereo, targetLufs: Double, report: (Int, String) -> Unit): MixReport {
        report(80, "Mastering: haavon'ny feo (loudness)...")
        var current = Loudness.measure(mix.l, mix.r, mix.n)
        // fetra: tsy mampiakatra mihoatra ny +30 dB (fahanginana saika tanteraka = tsy hanamafy sakantsakana)
        scale(mix, dbToLin(min(targetLufs - current, 30.0)).toFloat())
        Limiter.process(mix, ceilingDb = -1.0)

        for (pass in 0 until 3) {
            report(86 + pass * 3, "Mastering: fanatsaran-dalana ${pass + 1}/3...")
            current = Loudness.measure(mix.l, mix.r, mix.n)
            val diff = targetLufs - current
            if (abs(diff) < 0.4) break
            scale(mix, dbToLin(min(diff, 6.0)).toFloat())
            Limiter.process(mix, ceilingDb = -1.0)
        }

        val finalLufs = Loudness.measure(mix.l, mix.r, mix.n)
        val peak = Loudness.peakDb(mix.l, mix.r, mix.n)
        report(100, "Vita!")
        return MixReport(finalLufs, peak, mix.n.toDouble() / SR)
    }

    // =====================================================================
    // FOMBA FICHIER MITAMBATRA (vocal + instrumental efa niara-nitambatra)
    // =====================================================================

    /** Crossover 3 band (LR4 @150 Hz sy @4 kHz), mitambatra tsara amin'ny fanalana. */
    private class Crossover3 {
        private val loL = arrayOf(Biquad.lowpass(150.0), Biquad.lowpass(150.0))
        private val loR = arrayOf(Biquad.lowpass(150.0), Biquad.lowpass(150.0))
        private val miL = arrayOf(Biquad.lowpass(4000.0), Biquad.lowpass(4000.0))
        private val miR = arrayOf(Biquad.lowpass(4000.0), Biquad.lowpass(4000.0))

        fun split(x: Stereo, low: Stereo, mid: Stereo, high: Stereo) {
            for (i in 0 until x.n) {
                val xl = x.l[i]
                val xr = x.r[i]
                val ll = loL[1].process(loL[0].process(xl))
                val lr = loR[1].process(loR[0].process(xr))
                val rl = xl - ll
                val rr = xr - lr
                val ml = miL[1].process(miL[0].process(rl))
                val mr = miR[1].process(miR[0].process(rr))
                low.l[i] = ll; low.r[i] = lr
                mid.l[i] = ml; mid.r[i] = mr
                high.l[i] = rl - ml; high.r[i] = rr - mr
            }
            low.n = x.n; mid.n = x.n; high.n = x.n
        }
    }

    private const val BLOCK = 8192

    private fun newBlock() = Stereo(FloatArray(BLOCK), FloatArray(BLOCK), 0)

    private fun copyBlock(src: Stereo, start: Int, len: Int, dst: Stereo) {
        System.arraycopy(src.l, start, dst.l, 0, len)
        System.arraycopy(src.r, start, dst.r, 0, len)
        dst.n = len
    }

    /** RMS (dB) ny band 3 (ambany/afovoany/ambony), tsy raharahaina ny fianianana. */
    private fun bandLevels(src: Stereo): DoubleArray {
        val xo = Crossover3()
        val blk = newBlock(); val lo = newBlock(); val mi = newBlock(); val hi = newBlock()
        val sum = DoubleArray(3)
        var counted = 0L
        var start = 0
        while (start < src.n) {
            val len = min(BLOCK, src.n - start)
            copyBlock(src, start, len, blk)
            xo.split(blk, lo, mi, hi)
            val e = DoubleArray(3)
            for (i in 0 until len) {
                e[0] += (lo.l[i] * lo.l[i] + lo.r[i] * lo.r[i]).toDouble()
                e[1] += (mi.l[i] * mi.l[i] + mi.r[i] * mi.r[i]).toDouble()
                e[2] += (hi.l[i] * hi.l[i] + hi.r[i] * hi.r[i]).toDouble()
            }
            val total = (e[0] + e[1] + e[2]) / (2.0 * len)
            if (10 * kotlin.math.log10(total + 1e-12) > -60.0) {   // alefaso ny fahanginana
                for (b in 0 until 3) sum[b] += e[b]
                counted += len
            }
            start += len
        }
        return DoubleArray(3) {
            if (counted == 0L) -60.0 else 10 * kotlin.math.log10(sum[it] / (2.0 * counted) + 1e-12)
        }
    }

    /**
     * Mastering ny fichier mitambatra: bass matanjaka sy madio (mono ambanin'ny 120 Hz),
     * fanalana ny fitaoman'ny 280 Hz, presence ho an'ny feo (eo afovoany), de-esser,
     * reverb malefaka avy amin'ny feo afovoany, compressor 3 band, ary limiter.
     * Tsy miova ny timing: ny fanodinana rehetra dia IIR tsy misy latency, ary miara-mitsangana ny limiter.
     */
    fun processMerged(
        src: Stereo,
        s: MixSettings,
        report: (Int, String) -> Unit
    ): Pair<Stereo, MixReport> {
        val presenceDb = 1.5 + s.vocalDb * 0.5       // vocalDb = "presence feo" amin'ity fomba ity
        val bassDb = 1.5 + s.instDb * 0.5            // instDb = "bass"
        val tail = if (s.reverb > 0f) (SR * 2.5).toInt() else 0
        val total = src.n + tail
        val mix: Stereo = if (src.l.size >= total) src else
            Stereo(src.l.copyOf(total), src.r.copyOf(total), src.n)
        val srcN = src.n

        report(5, "Mandinika ny fifandanjalanjan'ny bass / afovoany / ambony...")
        val lv = bandLevels(mix.also { it.n = srcN })

        val pre = EqChain {
            listOf(
                Biquad.highpass(28.0),
                Biquad.lowShelf(90.0, bassDb),
                Biquad.peaking(280.0, 1.0, -1.5)
            )
        }
        val sideHp = Biquad.highpass(120.0)           // bass mono = bass madio (2 dingana = filtre 24 dB/oct)
        val sideHp2 = Biquad.highpass(120.0)
        val presEq = Biquad.peaking(3200.0, 0.9, presenceDb)
        val air = Biquad.highShelf(10000.0, 1.0)
        val deEss = DeEsser(thresholdRatio = 0.55, maxReductionDb = 5.0)
        val sendHp = Biquad.highpass(300.0)
        val sendLp = Biquad.lowpass(7000.0)
        val reverb = Reverb()
        val preDelay = FloatArray((SR * 0.020).toInt())
        var pi = 0
        val rg = s.reverb * 0.35f                     // malefaka kokoa noho ny fomba stems

        val xo = Crossover3()
        val compLow = Compressor(lv[0] + 1.0, 3.0, 20.0, 120.0, 6.0)
        val compMid = Compressor(lv[1] + 3.0, 2.0, 25.0, 150.0, 6.0)
        val compHigh = Compressor(lv[2] + 4.0, 2.0, 15.0, 100.0, 6.0)

        val blk = newBlock(); val bLow = newBlock(); val bMid = newBlock(); val bHigh = newBlock()
        val mid = FloatArray(BLOCK); val side = FloatArray(BLOCK)
        val midS = Stereo(mid, mid, 0)

        var start = 0
        while (start < total) {
            report(10 + (60L * start / total).toInt(), "Mixing + mastering (EQ, de-esser, reverb, compressor)...")
            val len = min(BLOCK, total - start)
            copyBlock(mix, start, len, blk)
            pre.process(blk)

            for (i in 0 until len) {
                mid[i] = (blk.l[i] + blk.r[i]) * 0.5f
                side[i] = (blk.l[i] - blk.r[i]) * 0.5f
            }
            sideHp.processInPlace(side, len)
            sideHp2.processInPlace(side, len)
            presEq.processInPlace(mid, len)
            air.processInPlace(mid, len)
            midS.n = len
            deEss.process(midS)

            for (i in 0 until len) {
                var wl = 0f
                var wr = 0f
                if (rg > 0f) {
                    val send = sendLp.process(sendHp.process(mid[i]))
                    val d = preDelay[pi]
                    preDelay[pi] = send
                    if (++pi >= preDelay.size) pi = 0
                    reverb.process(d)
                    wl = reverb.outL * rg
                    wr = reverb.outR * rg
                }
                blk.l[i] = mid[i] + side[i] + wl
                blk.r[i] = mid[i] - side[i] + wr
            }

            xo.split(blk, bLow, bMid, bHigh)
            compLow.process(bLow)
            compMid.process(bMid)
            compHigh.process(bHigh)
            for (i in 0 until len) {
                blk.l[i] = bLow.l[i] + bMid.l[i] + bHigh.l[i]
                blk.r[i] = bLow.r[i] + bMid.r[i] + bHigh.r[i]
            }
            System.arraycopy(blk.l, 0, mix.l, start, len)
            System.arraycopy(blk.r, 0, mix.r, start, len)
            start += len
        }
        mix.n = total

        return Pair(mix, finish(mix, s.targetLufs, report))
    }

    private fun scale(s: Stereo, g: Float) {
        for (i in 0 until s.n) {
            s.l[i] *= g
            s.r[i] *= g
        }
    }
}
