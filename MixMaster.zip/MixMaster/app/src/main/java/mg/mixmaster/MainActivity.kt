package mg.mixmaster

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private var uriA: Uri? = null          // fichier mitambatra, na feo irery
    private var uriB: Uri? = null          // mozika (tsy voatery)

    @Volatile private var result: Stereo? = null
    @Volatile private var busy = false
    @Volatile private var playing = false
    @Volatile private var stopFlag = false
    private var lastReport: MixReport? = null

    private lateinit var btnVocal: Button
    private lateinit var btnInst: Button
    private lateinit var btnProcess: Button
    private lateinit var btnPlay: Button
    private lateinit var btnWav: Button
    private lateinit var btnM4a: Button
    private lateinit var btnMp3: Button
    private lateinit var tvVocal: TextView
    private lateinit var tvInst: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvVocalVol: TextView
    private lateinit var tvInstVol: TextView
    private lateinit var tvReverb: TextView
    private lateinit var tvOffset: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvReport: TextView
    private lateinit var sbVocal: SeekBar
    private lateinit var sbInst: SeekBar
    private lateinit var sbReverb: SeekBar
    private lateinit var sbOffset: SeekBar
    private lateinit var pbar: ProgressBar
    private lateinit var rbSoft: RadioButton
    private lateinit var rbLoud: RadioButton

    private val pickA = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            uriA = uri
            tvVocal.text = displayName(uri)
            onInputsChanged()
        }
    }
    private val pickB = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            uriB = uri
            tvInst.text = displayName(uri)
            onInputsChanged()
        }
    }
    private val saveWav = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) export(uri, "wav")
    }
    private val saveM4a = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { uri ->
        if (uri != null) export(uri, "m4a")
    }
    private val saveMp3 = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { uri ->
        if (uri != null) export(uri, "mp3")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnVocal = findViewById(R.id.btnVocal)
        btnInst = findViewById(R.id.btnInst)
        btnProcess = findViewById(R.id.btnProcess)
        btnPlay = findViewById(R.id.btnPlay)
        btnWav = findViewById(R.id.btnWav)
        btnM4a = findViewById(R.id.btnM4a)
        btnMp3 = findViewById(R.id.btnMp3)
        tvVocal = findViewById(R.id.tvVocal)
        tvInst = findViewById(R.id.tvInst)
        tvMode = findViewById(R.id.tvMode)
        tvVocalVol = findViewById(R.id.tvVocalVol)
        tvInstVol = findViewById(R.id.tvInstVol)
        tvReverb = findViewById(R.id.tvReverb)
        tvOffset = findViewById(R.id.tvOffset)
        tvStatus = findViewById(R.id.tvStatus)
        tvReport = findViewById(R.id.tvReport)
        sbVocal = findViewById(R.id.sbVocal)
        sbInst = findViewById(R.id.sbInst)
        sbReverb = findViewById(R.id.sbReverb)
        sbOffset = findViewById(R.id.sbOffset)
        pbar = findViewById(R.id.pbar)
        rbSoft = findViewById(R.id.rbSoft)
        rbLoud = findViewById(R.id.rbLoud)

        val l = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = refreshLabels()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        sbVocal.setOnSeekBarChangeListener(l)
        sbInst.setOnSeekBarChangeListener(l)
        sbReverb.setOnSeekBarChangeListener(l)
        sbOffset.setOnSeekBarChangeListener(l)

        btnVocal.setOnClickListener { if (!busy) pickA.launch(arrayOf("audio/*")) }
        btnInst.setOnClickListener {
            if (!busy) pickB.launch(arrayOf("audio/*"))
        }
        btnInst.setOnLongClickListener {
            // tsindrio maharitra raha hanala ny fichier 2 (miverina amin'ny fomba mitambatra)
            if (!busy && uriB != null) {
                uriB = null
                tvInst.setText(R.string.not_selected)
                onInputsChanged()
            }
            true
        }
        btnProcess.setOnClickListener { startProcess() }
        btnPlay.setOnClickListener { togglePlay() }
        btnWav.setOnClickListener { saveWav.launch("mixmaster_${presetName()}.wav") }
        btnM4a.setOnClickListener { saveM4a.launch("mixmaster_${presetName()}.m4a") }
        btnMp3.setOnClickListener {
            if (Mp3Export.isAvailable()) saveMp3.launch("mixmaster_${presetName()}.mp3")
            else tvStatus.setText(R.string.mp3_unavailable)
        }
        onInputsChanged()
    }

    override fun onStop() {
        super.onStop()
        stopPlayback()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopFlag = true
    }

    // ------------------------------------------------------------------ UI

    private fun merged() = uriB == null

    private fun onInputsChanged() {
        stopPlayback()
        result = null
        setResultButtons(false)
        tvReport.text = ""
        tvMode.setText(if (merged()) R.string.mode_merged else R.string.mode_stems)
        sbOffset.isEnabled = !merged()
        refreshLabels()
    }

    private fun refreshLabels() {
        val v = sbVocal.progress - 12
        val i = sbInst.progress - 12
        if (merged()) {
            tvVocalVol.text = getString(R.string.lbl_presence, signed(v * 0.5))
            tvInstVol.text = getString(R.string.lbl_bass, signed(i * 0.5))
        } else {
            tvVocalVol.text = getString(R.string.lbl_vocal_vol, signed(v.toDouble()))
            tvInstVol.text = getString(R.string.lbl_inst_vol, signed(i.toDouble()))
        }
        tvReverb.text = getString(R.string.lbl_reverb, sbReverb.progress)
        tvOffset.text = getString(R.string.lbl_offset, sbOffset.progress)
    }

    private fun signed(x: Double): String = (if (x > 0) "+" else "") + (if (x == x.toInt().toDouble()) x.toInt().toString() else "%.1f".format(x))

    private fun presetName() = when {
        rbSoft.isChecked -> "soft"
        rbLoud.isChecked -> "loud"
        else -> "pro"
    }

    private fun targetLufs() = when {
        rbSoft.isChecked -> -14.0
        rbLoud.isChecked -> -9.0
        else -> -11.0
    }

    private fun setResultButtons(on: Boolean) {
        btnPlay.isEnabled = on
        btnWav.isEnabled = on
        btnM4a.isEnabled = on
        btnMp3.isEnabled = on
    }

    private fun setBusy(b: Boolean) {
        busy = b
        btnProcess.isEnabled = !b
        btnVocal.isEnabled = !b
        btnInst.isEnabled = !b
        if (b) setResultButtons(false) else setResultButtons(result != null)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return c.getString(idx) ?: uri.lastPathSegment.orEmpty()
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun post(progress: Int, msg: String?) {
        runOnUiThread {
            pbar.progress = progress.coerceIn(0, 100)
            if (msg != null) tvStatus.text = msg
        }
    }

    private fun fmtTime(sec: Double): String {
        val s = sec.toInt()
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ------------------------------------------------------------------ Processing

    private fun startProcess() {
        val a = uriA
        if (a == null) {
            tvStatus.setText(R.string.need_file)
            return
        }
        if (busy) return
        val b = uriB
        stopPlayback()
        result = null
        lastReport = null
        tvReport.text = ""
        setBusy(true)

        val settings = MixSettings(
            vocalDb = (sbVocal.progress - 12).toDouble(),
            instDb = (sbInst.progress - 12).toDouble(),
            reverb = sbReverb.progress / 100f,
            offsetMs = sbOffset.progress.toDouble(),
            targetLufs = targetLufs()
        )

        Thread {
            try {
                post(0, getString(R.string.decoding_1))
                val first = AudioIO.decode(this, a) { p -> post(if (b == null) p / 4 else p / 8, null) }
                val pair: Pair<Stereo, MixReport>
                if (b == null) {
                    pair = Mixer.processMerged(first, settings) { p, m -> post(15 + p * 85 / 100, m) }
                } else {
                    post(12, getString(R.string.decoding_2))
                    val second = AudioIO.decode(this, b) { p -> post(12 + p / 8, null) }
                    pair = Mixer.process(first, second, settings) { p, m -> post(25 + p * 75 / 100, m) }
                }
                result = pair.first
                lastReport = pair.second
                runOnUiThread {
                    tvStatus.setText(R.string.done)
                    tvReport.text = getString(
                        R.string.report_fmt, pair.second.lufs, pair.second.peakDb, fmtTime(pair.second.seconds)
                    )
                    pbar.progress = 100
                }
            } catch (e: OutOfMemoryError) {
                result = null
                runOnUiThread { tvStatus.setText(R.string.oom) }
            } catch (e: Exception) {
                result = null
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName) }
            } finally {
                runOnUiThread { setBusy(false) }
            }
        }.start()
    }

    // ------------------------------------------------------------------ Playback

    private fun togglePlay() {
        if (playing) {
            stopPlayback()
            return
        }
        val r = result ?: return
        if (busy) return
        playing = true
        stopFlag = false
        btnPlay.setText(R.string.stop)

        Thread {
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(max(minBuf, 65536))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val chunk = 8192
                val buf = ShortArray(chunk * 2)
                var pos = 0
                var lastUi = 0L
                val total = fmtTime(r.n.toDouble() / SR)
                while (pos < r.n && !stopFlag) {
                    val len = min(chunk, r.n - pos)
                    AudioIO.toPcm16(r, pos, len, buf)
                    track.write(buf, 0, len * 2)
                    pos += len
                    val now = System.currentTimeMillis()
                    if (now - lastUi > 500) {
                        lastUi = now
                        val cur = fmtTime(pos.toDouble() / SR)
                        runOnUiThread { tvStatus.text = "$cur / $total" }
                    }
                }
                if (!stopFlag) {
                    // avelao hifarana ny feo ao anaty buffer
                    try { Thread.sleep(300) } catch (_: InterruptedException) {}
                }
            } catch (e: Exception) {
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: "audio") }
            } finally {
                try { track?.stop() } catch (_: Exception) {}
                try { track?.release() } catch (_: Exception) {}
                playing = false
                runOnUiThread { btnPlay.setText(R.string.play) }
            }
        }.start()
    }

    private fun stopPlayback() {
        if (playing) stopFlag = true
    }

    // ------------------------------------------------------------------ Export

    private fun export(uri: Uri, kind: String) {
        val r = result ?: return
        if (busy) return
        stopPlayback()
        setBusy(true)
        runOnUiThread { tvStatus.setText(R.string.exporting); pbar.progress = 0 }
        Thread {
            try {
                when (kind) {
                    "wav" -> {
                        val os = contentResolver.openOutputStream(uri) ?: throw AudioException("Tsy afaka nanokatra ny fichier.")
                        os.buffered().use { AudioIO.writeWav(it, r) { p -> post(p, null) } }
                    }
                    "m4a" -> {
                        val tmp = File(cacheDir, "export.m4a")
                        try {
                            AudioIO.encodeAac(r, tmp, 256_000) { p -> post(p * 9 / 10, null) }
                            val os = contentResolver.openOutputStream(uri) ?: throw AudioException("Tsy afaka nanokatra ny fichier.")
                            tmp.inputStream().use { input -> os.use { out -> input.copyTo(out) } }
                        } finally {
                            tmp.delete()
                        }
                    }
                    "mp3" -> {
                        val os = contentResolver.openOutputStream(uri) ?: throw AudioException("Tsy afaka nanokatra ny fichier.")
                        os.buffered().use { Mp3Export.encode(r, it, 256) { p -> post(p, null) } }
                    }
                }
                runOnUiThread { tvStatus.setText(R.string.saved_ok); pbar.progress = 100 }
            } catch (e: Exception) {
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName) }
            } catch (e: OutOfMemoryError) {
                runOnUiThread { tvStatus.setText(R.string.oom) }
            } catch (e: Throwable) {
                // ohatra: UnsatisfiedLinkError avy amin'ny library MP3
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName) }
            } finally {
                runOnUiThread { setBusy(false) }
            }
        }.start()
    }
}
