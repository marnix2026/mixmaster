package mg.mixmaster

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AuphonicException(message: String) : Exception(message)

/**
 * Mpanjifa API Auphonic (https://auphonic.com/help/api/): mamorona asa, mampiakatra ny fichier,
 * manomboka, miandry ary misintona ny valiny WAV. Ny API key dia an'ny mpampiasa (misy ao amin'ny
 * auphonic.com/accounts/settings/#api-key). Ny fichier dia fafana ao amin'ny Auphonic aorian'ny fisintonana.
 */
object Auphonic {
    private const val BASE = "https://auphonic.com"

    enum class Kind {
        /** Vocal irery: leveler, compressor ary EQ ho azy. */
        VOCAL,
        /** Hira mitambatra: EQ ho azy fotsiny (tsy mikorontana ny dynamique). */
        FULL
    }

    private fun algorithms(kind: Kind): JSONObject {
        val a = JSONObject()
        a.put("filtering", true)
        a.put("filtermethod", "autoeq")      // EQ ho azy araka ny feo
        a.put("normloudness", false)         // ny haavon'ny hira dia ataon'ny app ao an-toerana
        a.put("denoise", false)
        if (kind == Kind.VOCAL) {
            a.put("leveler", true)
            a.put("levelerstrength", 80)
            a.put("compressor", "auto")
            a.put("msclassifier", "music")   // hira (tsy lahateny)
        } else {
            a.put("leveler", false)
            a.put("compressor", "off")
            a.put("msclassifier", "music")
        }
        return a
    }

    fun enhance(
        ctx: Context,
        input: Uri,
        displayName: String,
        apiKey: String,
        kind: Kind,
        onProgress: (Int, String) -> Unit
    ): File {
        onProgress(0, "mamorona ny asa...")
        val body = JSONObject()
            .put("metadata", JSONObject().put("title", "MixMaster"))
            .put("algorithms", algorithms(kind))
            .put("output_files", JSONArray().put(JSONObject().put("format", "wav").put("ending", "wav")))
        val created = requestJson("POST", "$BASE/api/productions.json", apiKey, body.toString())
        val uuid = created.optJSONObject("data")?.optString("uuid").orEmpty()
        if (uuid.isEmpty()) throw AuphonicException("tsy nahazo uuid avy amin'ny Auphonic")

        try {
            onProgress(5, "mampiakatra ny fichier...")
            val size = querySize(ctx, input)
            ctx.contentResolver.openInputStream(input)?.use { ins ->
                uploadMultipart(
                    "$BASE/api/production/$uuid/upload.json", apiKey, "input_file",
                    safeName(displayName), ins, size
                ) { pct -> onProgress(5 + pct * 25 / 100, "mampiakatra ny fichier... $pct%") }
            } ?: throw AuphonicException("tsy afaka namaky ny fichier")

            onProgress(30, "manomboka ny fanodinana...")
            requestJson("POST", "$BASE/api/production/$uuid/start.json", apiKey, null)

            // ---- miandry ----
            val t0 = System.currentTimeMillis()
            var outUrl: String? = null
            while (outUrl == null) {
                if (System.currentTimeMillis() - t0 > 20 * 60_000L) throw AuphonicException("lava loatra ny fiandrasana")
                Thread.sleep(3000)
                val d = requestJson("GET", "$BASE/api/production/$uuid.json", apiKey, null).optJSONObject("data")
                    ?: throw AuphonicException("valiny tsy mazava")
                val status = d.optInt("status", -1)
                val statusStr = d.optString("status_string", "")
                val err = d.optString("error_message", "")
                if (statusStr.equals("Error", true) || (err.isNotEmpty() && status != 3)) {
                    throw AuphonicException(if (err.isNotEmpty()) err else "hadisoana ao amin'ny Auphonic")
                }
                if (status == 3 || statusStr.equals("Done", true)) {
                    val files = d.optJSONArray("output_files")
                    if (files != null) {
                        for (i in 0 until files.length()) {
                            val f = files.getJSONObject(i)
                            val u = f.optString("download_url", "")
                            if (u.isNotEmpty() && (f.optString("format") == "wav" || outUrl == null)) outUrl = u
                        }
                    }
                    if (outUrl == null) throw AuphonicException("tsy nisy fichier vokatra")
                } else {
                    val elapsed = ((System.currentTimeMillis() - t0) / 1000).toInt()
                    onProgress(30 + min(60, elapsed / 2), if (statusStr.isEmpty()) "mandeha..." else statusStr.lowercase())
                }
            }

            onProgress(92, "misintona ny vokatra...")
            val out = File(ctx.cacheDir, "auphonic_$uuid.wav")
            download(outUrl!!, apiKey, out)
            onProgress(100, "vita")
            return out
        } finally {
            // fanajana ny fiainana manokana: fafana ao amin'ny Auphonic ny asa
            try { requestJson("DELETE", "$BASE/api/production/$uuid.json", apiKey, null) } catch (_: Exception) {}
        }
    }

    private fun min(a: Int, b: Int) = if (a < b) a else b

    private fun safeName(n: String): String {
        val s = n.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (s.isEmpty()) "audio.m4a" else s
    }

    private fun querySize(ctx: Context, uri: Uri): Long {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.SIZE)
                    if (i >= 0 && !c.isNull(i)) return c.getLong(i)
                }
            }
        } catch (_: Exception) {
        }
        return -1L
    }

    private fun open(method: String, url: String, key: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 30_000
        c.readTimeout = 120_000
        c.setRequestProperty("Authorization", "bearer $key")
        c.setRequestProperty("Accept", "application/json")
        return c
    }

    private fun readAll(ins: InputStream?): String =
        ins?.bufferedReader()?.use { it.readText() }.orEmpty()

    private fun failMessage(code: Int, body: String): String {
        val msg = try {
            val j = JSONObject(body)
            val e = j.optString("error_message", "")
            if (e.isNotEmpty()) e else j.optJSONObject("form_errors")?.toString().orEmpty()
        } catch (_: Exception) {
            body.take(120)
        }
        return when (code) {
            401 -> "API key diso (401)"
            402 -> "tapitra ny credits Auphonic (402)"
            403 -> "tsy navela (403)"
            else -> "HTTP $code${if (msg.isNotEmpty()) ": $msg" else ""}"
        }
    }

    private fun requestJson(method: String, url: String, key: String, json: String?): JSONObject {
        val c = open(method, url, key)
        try {
            if (json != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            } else if (method == "POST") {
                c.doOutput = true
                c.setFixedLengthStreamingMode(0)
                c.outputStream.close()
            }
            val code = c.responseCode
            val text = readAll(if (code >= 400) c.errorStream else c.inputStream)
            if (code >= 400) throw AuphonicException(failMessage(code, text))
            return if (text.isBlank()) JSONObject() else JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    private fun uploadMultipart(
        url: String, key: String, field: String, fileName: String,
        input: InputStream, total: Long, onPct: (Int) -> Unit
    ) {
        val boundary = "----MixMaster" + System.currentTimeMillis()
        val c = open("POST", url, key)
        try {
            c.doOutput = true
            c.setChunkedStreamingMode(64 * 1024)
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.outputStream.use { out ->
                val head = "--$boundary\r\nContent-Disposition: form-data; name=\"$field\"; filename=\"$fileName\"\r\n" +
                    "Content-Type: application/octet-stream\r\n\r\n"
                out.write(head.toByteArray(Charsets.UTF_8))
                val buf = ByteArray(64 * 1024)
                var sent = 0L
                var lastPct = -1
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    sent += n
                    if (total > 0) {
                        val pct = (100 * sent / total).toInt().coerceIn(0, 100)
                        if (pct != lastPct) { lastPct = pct; onPct(pct) }
                    }
                }
                out.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
            }
            val code = c.responseCode
            val text = readAll(if (code >= 400) c.errorStream else c.inputStream)
            if (code >= 400) throw AuphonicException(failMessage(code, text))
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, key: String, dest: File) {
        // ny "bearer_token" ao amin'ny URL dia mahazaka ny redirect (araka ny fanoritsoritana ofisialy)
        val sep = if (url.contains("?")) "&" else "?"
        val c = URL(url + sep + "bearer_token=" + URLEncoder.encode(key, "UTF-8")).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects = true
            c.connectTimeout = 30_000
            c.readTimeout = 120_000
            val code = c.responseCode
            if (code >= 400) throw AuphonicException(failMessage(code, readAll(c.errorStream)))
            c.inputStream.use { ins -> FileOutputStream(dest).use { out -> ins.copyTo(out) } }
        } finally {
            c.disconnect()
        }
        if (dest.length() < 1000) throw AuphonicException("fichier vokatra kely loatra")
    }
}
