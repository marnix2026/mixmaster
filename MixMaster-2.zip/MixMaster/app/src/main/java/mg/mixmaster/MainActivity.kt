package mg.mixmaster

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import java.io.File
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private var uriA: Uri? = null          // fichier 1: hira mitambatra, na feo/mozika
    private var uriB: Uri? = null          // fichier 2: mozika (na feo), tsy voatery

    @Volatile private var result: Stereo? = null
    @Volatile private var reference: Stereo? = null     // ny "taloha", haavo mitovy amin'ny vita
    @Volatile private var lastReport: MixReport? = null
    @Volatile private var busy = false

    // fihainoana
    @Volatile private var playToken = 0
    @Volatile private var playingWhich: String? = null   // "proc" | "orig" | null
    @Volatile private var lastPos = 0

    private lateinit var btnVocal: Button
    private lateinit var btnInst: Button
    private lateinit var btnProcess: Button
    private lateinit var btnPlay: Button
    private lateinit var btnPlayOrig: Button
    private lateinit var btnWav: Button
    private lateinit var btnM4a: Button
    private lateinit var btnMp3: Button
    private lateinit var tvVocal: TextView
    private lateinit var tvInst: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvReport: TextView
    private lateinit var pbar: ProgressBar
    private lateinit var rbNatural: RadioButton
    private lateinit var rbLoud: RadioButton
    private lateinit var switchAi: SwitchCompat
    private lateinit var etKey: EditText
    private lateinit var tvAiStatus: TextView

    private val pickA = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            uriA = uri
            tvVocal.text = displayName(uri)
            onInputsChanged()
        }
    }
    private val pickB = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            uriB = uri
            tvInst.text = displayName(uri)
            onInputsChanged()
        }
    }
    private val saveWav = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) export(uri, "wav")
    }
    private val saveM4a = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { uri ->
        if (uri != null) export(uri, "m4a")
    }
    private val saveMp3 = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { uri ->
        if (uri != null) export(uri, "mp3")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnVocal = findViewById(R.id.btnVocal)
        btnInst = findViewById(R.id.btnInst)
        btnProcess = findViewById(R.id.btnProcess)
        btnPlay = findViewById(R.id.btnPlay)
        btnPlayOrig = findViewById(R.id.btnPlayOrig)
        btnWav = findViewById(R.id.btnWav)
        btnM4a = findViewById(R.id.btnM4a)
        btnMp3 = findViewById(R.id.btnMp3)
        tvVocal = findViewById(R.id.tvVocal)
        tvInst = findViewById(R.id.tvInst)
        tvMode = findViewById(R.id.tvMode)
        tvStatus = findViewById(R.id.tvStatus)
        tvReport = findViewById(R.id.tvReport)
        pbar = findViewById(R.id.pbar)
        rbNatural = findViewById(R.id.rbNatural)
        rbLoud = findViewById(R.id.rbLoud)
        switchAi = findViewById(R.id.switchAi)
        etKey = findViewById(R.id.etKey)
        tvAiStatus = findViewById(R.id.tvAiStatus)

        val prefs = getSharedPreferences("mixmaster", Context.MODE_PRIVATE)
        etKey.setText(prefs.getString("auphonic_key", ""))
        switchAi.isChecked = prefs.getBoolean("ai_on", false)

        btnVocal.setOnClickListener { if (!busy) pickA.launch(arrayOf("audio/*")) }
        btnInst.setOnClickListener { if (!busy) pickB.launch(arrayOf("audio/*")) }
        btnInst.setOnLongClickListener {
            // tsindrio maharitra = esorina ny fichier 2 (miverina amin'ny fomba fichier iray)
            if (!busy && uriB != null) {
                uriB = null
                tvInst.setText(R.string.not_selected)
                onInputsChanged()
            }
            true
        }
        btnProcess.setOnClickListener { startProcess() }
        btnPlay.setOnClickListener { togglePlay("proc") }
        btnPlayOrig.setOnClickListener { togglePlay("orig") }
        btnWav.setOnClickListener { saveWav.launch("mixmaster_${preset().label.lowercase()}.wav") }
        btnM4a.setOnClickListener { saveM4a.launch("mixmaster_${preset().label.lowercase()}.m4a") }
        btnMp3.setOnClickListener {
            if (Mp3Export.isAvailable()) saveMp3.launch("mixmaster_${preset().label.lowercase()}.mp3")
            else tvStatus.setText(R.string.mp3_unavailable)
        }
        onInputsChanged()
    }

    override fun onStop() {
        super.onStop()
        stopPlayback()
    }

    // ------------------------------------------------------------------ UI

    private fun preset(): Preset = when {
        rbNatural.isChecked -> Preset.NATUREL
        rbLoud.isChecked -> Preset.LOUD
        else -> Preset.UNIVERSAL
    }

    private fun onInputsChanged() {
        stopPlayback()
        result = null
        reference = null
        lastReport = null
        setResultButtons(false)
        tvReport.text = ""
        tvMode.setText(if (uriB == null) R.string.mode_merged else R.string.mode_stems)
    }

    private fun setResultButtons(on: Boolean) {
        btnPlay.isEnabled = on
        btnPlayOrig.isEnabled = on
        btnWav.isEnabled = on
        btnM4a.isEnabled = on
        btnMp3.isEnabled = on
    }

    private fun setBusy(b: Boolean) {
        busy = b
        btnProcess.isEnabled = !b
        btnVocal.isEnabled = !b
        btnInst.isEnabled = !b
        if (b) setResultButtons(false) else setResultButtons(result != null)
    }

    private fun updatePlayButtons() {
        btnPlay.setText(if (playingWhich == "proc") R.string.stop_proc else R.string.play_proc)
        btnPlayOrig.setText(if (playingWhich == "orig") R.string.stop_orig else R.string.play_orig)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return c.getString(idx) ?: uri.lastPathSegment.orEmpty()
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun post(progress: Int, msg: String?) {
        runOnUiThread {
            pbar.progress = progress.coerceIn(0, 100)
            if (msg != null) tvStatus.text = msg
        }
    }

    private fun fmtTime(sec: Double): String {
        val s = sec.toInt()
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ------------------------------------------------------------------ Processing

    /** Mampiasa ny AI Auphonic. Raha tsy nahomby dia mamerina null (mitohy tsy misy AI). */
    private fun aiEnhance(uri: Uri, name: String, key: String, kind: Auphonic.Kind, from: Int, to: Int): Stereo? {
        return try {
            val f = Auphonic.enhance(this, uri, name, key, kind) { pr, m ->
                post(from + pr * (to - from) / 100, getString(R.string.ai_working, m))
            }
            try {
                AudioIO.decode(this, Uri.fromFile(f)) { }
            } finally {
                f.delete()
            }
        } catch (e: OutOfMemoryError) {
            runOnUiThread { tvAiStatus.text = getString(R.string.ai_fail, "memoria") }
            null
        } catch (e: Exception) {
            runOnUiThread { tvAiStatus.text = getString(R.string.ai_fail, e.message ?: e.javaClass.simpleName) }
            null
        }
    }

    private fun startProcess() {
        val a = uriA
        if (a == null) {
            tvStatus.setText(R.string.need_file)
            return
        }
        if (busy) return
        val useAi = switchAi.isChecked
        val key = etKey.text.toString().trim()
        if (useAi && key.isEmpty()) {
            tvAiStatus.setText(R.string.ai_need_key)
            return
        }
        getSharedPreferences("mixmaster", Context.MODE_PRIVATE).edit()
            .putString("auphonic_key", key).putBoolean("ai_on", useAi).apply()
        tvAiStatus.text = ""

        val b = uriB
        val p = preset()
        stopPlayback()
        result = null
        reference = null
        lastReport = null
        tvReport.text = ""
        setBusy(true)

        Thread {
            try {
                val pair: Pair<Stereo, MixReport>
                if (b == null) {
                    // ---- fichier iray (hira mitambatra) ----
                    var first: Stereo? = null
                    if (useAi) {
                        post(0, getString(R.string.decoding_1))
                        first = aiEnhance(a, displayName(a), key, Auphonic.Kind.FULL, 0, 55)
                        if (first != null) runOnUiThread { tvAiStatus.setText(R.string.ai_ok) }
                    }
                    val base = if (first != null) 55 else 15
                    if (first == null) {
                        post(0, getString(R.string.decoding_1))
                        first = AudioIO.decode(this, a) { pr -> post(pr / 4, null) }
                    }
                    pair = Mixer.processMerged(first, p) { pr, m -> post(base + pr * (100 - base) / 100, m) }
                } else {
                    // ---- vocal + instrumental misaraka ----
                    post(0, getString(R.string.decoding_1))
                    val first = AudioIO.decode(this, a) { pr -> post(pr / 8, null) }
                    post(12, getString(R.string.decoding_2))
                    val second = AudioIO.decode(this, b) { pr -> post(12 + pr / 8, null) }

                    post(24, getString(R.string.detecting))
                    val nameA = displayName(a)
                    val nameB = displayName(b)
                    val swap = RoleDetector.shouldSwap(nameA, nameB, first, second)
                    var vocal = if (swap) second else first
                    val inst = if (swap) first else second
                    val vocalUri = if (swap) b else a
                    val vocalName = if (swap) nameB else nameA
                    val instName = if (swap) nameA else nameB
                    runOnUiThread {
                        tvMode.text = getString(
                            R.string.roles_fmt, vocalName, instName,
                            if (swap) getString(R.string.roles_swapped) else ""
                        )
                    }

                    var base = 27
                    if (useAi) {
                        val enhanced = aiEnhance(vocalUri, vocalName, key, Auphonic.Kind.VOCAL, 26, 60)
                        if (enhanced != null) {
                            vocal = enhanced
                            base = 60
                            runOnUiThread { tvAiStatus.setText(R.string.ai_ok) }
                        }
                    }
                    pair = Mixer.process(vocal, inst, p) { pr, m -> post(base + pr * (100 - base) / 100, m) }
                }
                result = pair.first
                lastReport = pair.second
                runOnUiThread {
                    tvStatus.setText(R.string.done)
                    tvReport.text = getString(
                        R.string.report_fmt, pair.second.lufs, pair.second.peakDb, fmtTime(pair.second.seconds)
                    )
                    pbar.progress = 100
                }
            } catch (e: OutOfMemoryError) {
                result = null
                runOnUiThread { tvStatus.setText(R.string.oom) }
            } catch (e: Exception) {
                result = null
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName) }
            } finally {
                runOnUiThread { setBusy(false) }
            }
        }.start()
    }

    /** Mamoaka ny "taloha": ny fichier (na ny fichier roa nambatana) avy amin'ny voalohany, haavo mitovy amin'ny vita. */
    private fun buildReference(): Stereo {
        reference?.let { return it }
        val a = uriA ?: throw AudioException("Tsy hita ny fichier.")
        val b = uriB
        var ref = AudioIO.decode(this, a) { pr -> post(pr / 2, null) }
        if (b != null) {
            val other = AudioIO.decode(this, b) { pr -> post(30 + pr / 2, null) }
            val n = max(ref.n, other.n)
            if (ref.l.size < n) {
                ref = Stereo(ref.l.copyOf(n), ref.r.copyOf(n), ref.n)
            }
            for (i in 0 until other.n) {
                ref.l[i] += other.l[i]
                ref.r[i] += other.r[i]
            }
            ref.n = n
        }
        lastReport?.let { Mixer.matchLoudness(ref, it.lufs) }
        reference = ref
        return ref
    }

    // ------------------------------------------------------------------ Playback

    private fun togglePlay(which: String) {
        if (busy) return
        if (playingWhich == which) {
            stopPlayback()
            return
        }
        val from = if (playingWhich != null) lastPos else 0     // mifandimby amin'ny toerana mitovy
        val proc = result ?: return
        // fampiharana: raha tsy mbola voaomana ny "taloha", mamoaka azy aloha
        if (which == "orig" && reference == null) {
            setBusy(true)
            post(0, getString(R.string.building_ref))
            Thread {
                try {
                    val ref = buildReference()
                    runOnUiThread { setBusy(false); startPlayback("orig", ref, from) }
                } catch (e: OutOfMemoryError) {
                    reference = null
                    runOnUiThread { setBusy(false); tvStatus.setText(R.string.oom) }
                } catch (e: Exception) {
                    runOnUiThread { setBusy(false); tvStatus.text = getString(R.string.error_prefix, e.message ?: "audio") }
                }
            }.start()
            return
        }
        startPlayback(which, if (which == "orig") reference!! else proc, from)
    }

    private fun startPlayback(which: String, r: Stereo, fromFrame: Int) {
        val my = ++playToken
        playingWhich = which
        updatePlayButtons()

        Thread {
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(max(minBuf, 65536))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val chunk = 4096
                val buf = ShortArray(chunk * 2)
                var pos = min(fromFrame, max(0, r.n - 1))
                var lastUi = 0L
                val total = fmtTime(r.n.toDouble() / SR)
                while (pos < r.n && my == playToken) {
                    val len = min(chunk, r.n - pos)
                    AudioIO.toPcm16(r, pos, len, buf)
                    track.write(buf, 0, len * 2)
                    pos += len
                    lastPos = pos
                    val now = System.currentTimeMillis()
                    if (now - lastUi > 500) {
                        lastUi = now
                        val cur = fmtTime(pos.toDouble() / SR)
                        val tag = if (which == "orig") "Taloha" else "Vita"
                        runOnUiThread { tvStatus.text = "$tag  $cur / $total" }
                    }
                }
                if (my == playToken) {
                    // avelao hifarana ny feo ao anaty buffer
                    try { Thread.sleep(300) } catch (_: InterruptedException) {}
                }
            } catch (e: Exception) {
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: "audio") }
            } finally {
                try { track?.stop() } catch (_: Exception) {}
                try { track?.release() } catch (_: Exception) {}
                if (my == playToken) {
                    playingWhich = null
                    lastPos = 0
                }
                runOnUiThread { updatePlayButtons() }
            }
        }.start()
    }

    private fun stopPlayback() {
        playToken++
        playingWhich = null
        updatePlayButtons()
    }

    // ------------------------------------------------------------------ Export

    private fun export(uri: Uri, kind: String) {
        val r = result ?: return
        if (busy) return
        stopPlayback()
        setBusy(true)
        runOnUiThread { tvStatus.setText(R.string.exporting); pbar.progress = 0 }
        Thread {
            try {
                when (kind) {
                    "wav" -> {
                        val os = contentResolver.openOutputStream(uri) ?: throw AudioException("Tsy afaka nanokatra ny fichier.")
                        os.buffered().use { AudioIO.writeWav(it, r) { pr -> post(pr, null) } }
                    }
                    "m4a" -> {
                        val tmp = File(cacheDir, "export.m4a")
                        try {
                            AudioIO.encodeAac(r, tmp, 256_000) { pr -> post(pr * 9 / 10, null) }
                            val os = contentResolver.openOutputStream(uri) ?: throw AudioException("Tsy afaka nanokatra ny fichier.")
                            tmp.inputStream().use { input -> os.use { out -> input.copyTo(out) } }
                        } finally {
                            tmp.delete()
                        }
                    }
                    "mp3" -> {
                        val os = contentResolver.openOutputStream(uri) ?: throw AudioException("Tsy afaka nanokatra ny fichier.")
                        os.buffered().use { Mp3Export.encode(r, it, 256) { pr -> post(pr, null) } }
                    }
                }
                runOnUiThread { tvStatus.setText(R.string.saved_ok); pbar.progress = 100 }
            } catch (e: Exception) {
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName) }
            } catch (e: OutOfMemoryError) {
                runOnUiThread { tvStatus.setText(R.string.oom) }
            } catch (e: Throwable) {
                // ohatra: UnsatisfiedLinkError avy amin'ny library MP3
                runOnUiThread { tvStatus.text = getString(R.string.error_prefix, e.message ?: e.javaClass.simpleName) }
            } finally {
                runOnUiThread { setBusy(false) }
            }
        }.start()
    }
}
