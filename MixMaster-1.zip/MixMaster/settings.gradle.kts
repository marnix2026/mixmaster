pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Ilaina ho an'ny encoder MP3 (LAME) fotsiny: azo esorina raha tsy ampiasaina
        maven { url = uri("https://jitpack.io") }
    }
}
rootProject.name = "MixMaster"
include(":app")
