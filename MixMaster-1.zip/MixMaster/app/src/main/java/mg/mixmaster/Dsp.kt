package mg.mixmaster

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Fatran'ny santionany ampiasain'ny rindrambaiko manontolo. */
const val SR = 44100

/** Feo stereo: arrays mety ho lehibe kokoa noho [n] (ny faritra aoriana dia zero). */
class Stereo(var l: FloatArray, var r: FloatArray, var n: Int)

fun dbToLin(db: Double): Double = 10.0.pow(db / 20.0)
fun linToDb(x: Double): Double = 20.0 * log10(max(x, 1e-9))

// ---------------------------------------------------------------------------
// Biquad (RBJ Audio EQ Cookbook)
// ---------------------------------------------------------------------------
class Biquad private constructor(
    private val b0: Double, private val b1: Double, private val b2: Double,
    private val a1: Double, private val a2: Double
) {
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = xd
        y2 = y1; y1 = y
        return y.toFloat()
    }

    fun processInPlace(buf: FloatArray, n: Int) {
        for (i in 0 until n) buf[i] = process(buf[i])
    }

    companion object {
        private fun make(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) =
            Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)

        fun highpass(f: Double, q: Double = 0.7071): Biquad {
            val w = 2 * PI * f / SR; val c = cos(w); val al = sin(w) / (2 * q)
            return make((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
        }

        fun lowpass(f: Double, q: Double = 0.7071): Biquad {
            val w = 2 * PI * f / SR; val c = cos(w); val al = sin(w) / (2 * q)
            return make((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
        }

        fun bandpass(f: Double, q: Double): Biquad {
            val w = 2 * PI * f / SR; val c = cos(w); val al = sin(w) / (2 * q)
            return make(al, 0.0, -al, 1 + al, -2 * c, 1 - al)
        }

        fun peaking(f: Double, q: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40.0)
            val w = 2 * PI * f / SR; val c = cos(w); val al = sin(w) / (2 * q)
            return make(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
        }

        fun lowShelf(f: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40.0)
            val w = 2 * PI * f / SR; val c = cos(w)
            val beta = 2 * sqrt(a) * (sin(w) / 2 * sqrt(2.0))
            return make(
                a * ((a + 1) - (a - 1) * c + beta),
                2 * a * ((a - 1) - (a + 1) * c),
                a * ((a + 1) - (a - 1) * c - beta),
                (a + 1) + (a - 1) * c + beta,
                -2 * ((a - 1) + (a + 1) * c),
                (a + 1) + (a - 1) * c - beta
            )
        }

        fun highShelf(f: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40.0)
            val w = 2 * PI * f / SR; val c = cos(w)
            val beta = 2 * sqrt(a) * (sin(w) / 2 * sqrt(2.0))
            return make(
                a * ((a + 1) + (a - 1) * c + beta),
                -2 * a * ((a - 1) + (a + 1) * c),
                a * ((a + 1) + (a - 1) * c - beta),
                (a + 1) - (a - 1) * c + beta,
                2 * ((a - 1) - (a + 1) * c),
                (a + 1) - (a - 1) * c - beta
            )
        }
    }
}

/** Fanamboarana filtre mitovy isaky ny lalana (L/R). */
class EqChain(private val factory: () -> List<Biquad>) {
    private val left = factory()
    private val right = factory()

    fun process(s: Stereo) {
        for (f in left) f.processInPlace(s.l, s.n)
        for (f in right) f.processInPlace(s.r, s.n)
    }
}

// ---------------------------------------------------------------------------
// Compressor stereo (detector mifandray)
// ---------------------------------------------------------------------------
class Compressor(
    private val thrDb: Double,
    private val ratio: Double,
    attackMs: Double,
    releaseMs: Double,
    private val kneeDb: Double = 6.0
) {
    private val ac = exp(-1.0 / (attackMs * 0.001 * SR))
    private val rc = exp(-1.0 / (releaseMs * 0.001 * SR))
    private var gr = 0.0   // state mitazona eo anelanelan'ny bloc

    /** Mamerina ny salan'ny gain reduction (dB). Azo antsoina isaky ny bloc. */
    fun process(s: Stereo, makeupDb: Double = 0.0): Double {
        val makeup = dbToLin(makeupDb).toFloat()
        var grSum = 0.0
        for (i in 0 until s.n) {
            val peak = max(abs(s.l[i]), abs(s.r[i])).toDouble()
            val x = 20.0 * log10(max(peak, 1e-6))
            val over = x - thrDb
            val out = when {
                2 * over < -kneeDb -> x
                2 * abs(over) <= kneeDb -> x + (1.0 / ratio - 1.0) * (over + kneeDb / 2).pow(2) / (2 * kneeDb)
                else -> thrDb + over / ratio
            }
            val target = x - out
            gr = if (target > gr) ac * gr + (1 - ac) * target else rc * gr + (1 - rc) * target
            grSum += gr
            val g = (10.0.pow(-gr / 20.0)).toFloat() * makeup
            s.l[i] *= g
            s.r[i] *= g
        }
        return if (s.n > 0) grSum / s.n else 0.0
    }
}

// ---------------------------------------------------------------------------
// De-esser: mampihena ny "s" mahery vokatra fotsiny (band 6.5 kHz)
// ---------------------------------------------------------------------------
class DeEsser(
    private val freq: Double = 6500.0,
    private val thresholdRatio: Double = 0.45,
    private val maxReductionDb: Double = 9.0
) {
    private val bpL = Biquad.bandpass(freq, 1.2)
    private val bpR = Biquad.bandpass(freq, 1.2)
    private val ac = exp(-1.0 / (0.001 * SR))
    private val rc = exp(-1.0 / (0.040 * SR))
    private var envSib = 0.0
    private var envAll = 0.0
    private var grDb = 0.0
    private val grAtt = exp(-1.0 / (0.002 * SR))
    private val grRel = exp(-1.0 / (0.050 * SR))

    /** Azo antsoina isaky ny bloc: mitazona ny state rehetra. */
    fun process(s: Stereo) {
        for (i in 0 until s.n) {
            val x1 = s.l[i]
            val x2 = s.r[i]
            val sl = bpL.process(x1)
            val sr = bpR.process(x2)
            val sib = max(abs(sl), abs(sr)).toDouble()
            val all = max(abs(x1), abs(x2)).toDouble()
            envSib = if (sib > envSib) ac * envSib + (1 - ac) * sib else rc * envSib + (1 - rc) * sib
            envAll = if (all > envAll) ac * envAll + (1 - ac) * all else rc * envAll + (1 - rc) * all
            val ratio = envSib / (envAll + 1e-6)
            val target = if (ratio > thresholdRatio && envAll > 0.003)
                min(maxReductionDb, 20.0 * log10(ratio / thresholdRatio)) else 0.0
            grDb = if (target > grDb) grAtt * grDb + (1 - grAtt) * target else grRel * grDb + (1 - grRel) * target
            val k = (1.0 - 10.0.pow(-grDb / 20.0)).toFloat()
            s.l[i] = x1 - sl * k
            s.r[i] = x2 - sr * k
        }
    }
}

// ---------------------------------------------------------------------------
// Reverb (Freeverb)
// ---------------------------------------------------------------------------
class Reverb(room: Float = 0.86f, damp: Float = 0.25f) {
    private class Comb(size: Int, private val fb: Float, private val damp: Float) {
        private val buf = FloatArray(size)
        private var idx = 0
        private var store = 0f
        fun process(x: Float): Float {
            val out = buf[idx]
            store = out * (1 - damp) + store * damp
            buf[idx] = x + store * fb
            if (++idx >= buf.size) idx = 0
            return out
        }
    }

    private class Allpass(size: Int) {
        private val buf = FloatArray(size)
        private var idx = 0
        fun process(x: Float): Float {
            val b = buf[idx]
            val out = -x + b
            buf[idx] = x + b * 0.5f
            if (++idx >= buf.size) idx = 0
            return out
        }
    }

    private val combTune = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val apTune = intArrayOf(556, 441, 341, 225)
    private val spread = 23
    private val combL = Array(8) { Comb(combTune[it], room, damp) }
    private val combR = Array(8) { Comb(combTune[it] + spread, room, damp) }
    private val apL = Array(4) { Allpass(apTune[it]) }
    private val apR = Array(4) { Allpass(apTune[it] + spread) }

    var outL = 0f
        private set
    var outR = 0f
        private set

    fun process(input: Float) {
        val x = input * 0.015f
        var l = 0f
        var r = 0f
        for (c in combL) l += c.process(x)
        for (c in combR) r += c.process(x)
        for (a in apL) l = a.process(l)
        for (a in apR) r = a.process(r)
        outL = l
        outR = r
    }
}

// ---------------------------------------------------------------------------
// Loudness (BS.1770, K-weighting + gating)
// ---------------------------------------------------------------------------
object Loudness {
    /** Mamerina LUFS integrated (gated). [gain] = fanamafisana alohan'ny refy. */
    fun measure(
        l: FloatArray, r: FloatArray, n: Int, gain: Float = 1f,
        pre: (() -> List<Biquad>)? = null          // sivana alohan'ny K-weighting (ohatra: band afovoany)
    ): Double {
        val fl = (pre?.invoke() ?: emptyList()) + listOf(Biquad.highShelf(1681.97, 3.99), Biquad.highpass(38.135, 0.5003))
        val fr = (pre?.invoke() ?: emptyList()) + listOf(Biquad.highShelf(1681.97, 3.99), Biquad.highpass(38.135, 0.5003))
        val chunk = SR / 10
        val chunkEnergy = ArrayList<Double>()
        var acc = 0.0
        var cnt = 0
        for (i in 0 until n) {
            var a = l[i] * gain
            var b = r[i] * gain
            for (f in fl) a = f.process(a)
            for (f in fr) b = f.process(b)
            acc += (a * a + b * b).toDouble()
            if (++cnt == chunk) {
                chunkEnergy.add(acc / chunk)
                acc = 0.0
                cnt = 0
            }
        }
        if (chunkEnergy.size < 4) {
            // hira fohy loatra: ampiasaina ny salan'ny rehetra
            val e = chunkEnergy.sum() / max(1, chunkEnergy.size)
            return if (e <= 0) -70.0 else -0.691 + 10 * log10(e)
        }
        val blocks = DoubleArray(chunkEnergy.size - 3) {
            (chunkEnergy[it] + chunkEnergy[it + 1] + chunkEnergy[it + 2] + chunkEnergy[it + 3]) / 4.0
        }
        fun lufs(z: Double) = -0.691 + 10 * log10(max(z, 1e-12))
        val abs = blocks.filter { lufs(it) > -70.0 }
        if (abs.isEmpty()) return -70.0
        val relThr = lufs(abs.average()) - 10.0
        val rel = abs.filter { lufs(it) > relThr }
        if (rel.isEmpty()) return lufs(abs.average())
        return lufs(rel.average())
    }

    fun peakDb(l: FloatArray, r: FloatArray, n: Int): Double {
        var p = 0f
        for (i in 0 until n) p = max(p, max(abs(l[i]), abs(r[i])))
        return linToDb(p.toDouble())
    }
}

// ---------------------------------------------------------------------------
// Limiter "lookahead" (tsy mamela ny peak hihoatra ny ceiling)
// ---------------------------------------------------------------------------
object Limiter {
    fun process(s: Stereo, ceilingDb: Double = -1.0, releaseMs: Double = 80.0) {
        val l = s.l
        val r = s.r
        val n = s.n
        val ceil = dbToLin(ceilingDb).toFloat()
        val la = (SR * 0.005).toInt()                 // lookahead 5 ms
        val rc = (1.0 - exp(-1.0 / (releaseMs * 0.001 * SR))).toFloat()

        val dqSize = la + 2
        val dqIdx = IntArray(dqSize)
        val dqVal = FloatArray(dqSize)
        var head = 0
        var tail = 0
        var count = 0

        val ring = FloatArray(la + 1) { 1f }
        var ringSum = (la + 1).toDouble()
        var ringPos = 0
        var rPrev = 1f

        for (k in 0 until n + la) {
            val tg = if (k < n) {
                val p = max(abs(l[k]), abs(r[k]))
                if (p > ceil) ceil / p else 1f
            } else 1f

            while (count > 0 && dqVal[(tail - 1 + dqSize) % dqSize] >= tg) {
                tail = (tail - 1 + dqSize) % dqSize
                count--
            }
            dqIdx[tail] = k
            dqVal[tail] = tg
            tail = (tail + 1) % dqSize
            count++
            while (dqIdx[head] < k - la) {
                head = (head + 1) % dqSize
                count--
            }

            if (k >= la) {
                val i = k - la
                val m = dqVal[head]
                var rr = rPrev + (1f - rPrev) * rc
                if (m < rr) rr = m
                rPrev = rr
                ringSum += (rr - ring[ringPos]).toDouble()
                ring[ringPos] = rr
                ringPos = (ringPos + 1) % (la + 1)
                val g = (ringSum / (la + 1)).toFloat()
                l[i] = (l[i] * g).coerceIn(-ceil, ceil)
                r[i] = (r[i] * g).coerceIn(-ceil, ceil)
            }
        }
    }
}


// ---------------------------------------------------------------------------
// Auto-level ny feo: mampitovy ny haavon'ny andian-teny (phrase) mba tsy hisy mahery/malemy loatra
// ---------------------------------------------------------------------------
class VocalRider(private val maxBoostDb: Double = 6.0, private val maxCutDb: Double = 6.0) {
    /** Haavon'ny feo ao anatin'ny faritra misy feo (dB RMS), tsy raharahaina ny fahanginana. */
    private fun activeLevelDb(s: Stereo): Pair<Double, Double> {
        val frame = SR / 20                    // 50 ms
        val nf = s.n / frame
        if (nf < 4) return Pair(-120.0, -120.0)
        val db = DoubleArray(nf)
        var maxDb = -200.0
        for (f in 0 until nf) {
            var p = 0.0
            for (i in f * frame until (f + 1) * frame) {
                val m = 0.5 * (s.l[i] + s.r[i])
                p += m * m
            }
            db[f] = 10 * log10(p / frame + 1e-12)
            if (db[f] > maxDb) maxDb = db[f]
        }
        var sum = 0.0
        var cnt = 0
        for (d in db) if (d > maxDb - 30) { sum += 10.0.pow(d / 10); cnt++ }
        return Pair(10 * log10(sum / max(1, cnt) + 1e-12), maxDb)
    }

    fun process(s: Stereo) {
        val (target, maxDb) = activeLevelDb(s)
        if (maxDb < -100) return
        val gate = maxDb - 32                  // ambanin'izany: fahanginana/taovam-pifaliana, tsy hasiana fanamafisana
        val envC = exp(-1.0 / (0.060 * SR))
        val atk = exp(-1.0 / (0.040 * SR))     // mampihena haingana rehefa mahery
        val rel = exp(-1.0 / (0.400 * SR))     // mampiakatra miadana rehefa malemy
        var env = 0.0
        var g = 0.0
        for (i in 0 until s.n) {
            val m = 0.5 * (s.l[i] + s.r[i])
            env = envC * env + (1 - envC) * m * m
            val lvl = 10 * log10(env + 1e-12)
            val desired = if (lvl < gate) 0.0 else (target - lvl).coerceIn(-maxCutDb, maxBoostDb)
            g = if (desired < g) atk * g + (1 - atk) * desired else rel * g + (1 - rel) * desired
            val lin = 10.0.pow(g / 20.0).toFloat()
            s.l[i] *= lin
            s.r[i] *= lin
        }
    }
}

// ---------------------------------------------------------------------------
// Fanitsiana EQ ho azy ny feo: manadio ny fitaomana (mud), presence ary "air" araka ny feo tena misy
// (heuristic malefaka: fanitsiana ≤ 3 dB, ary tsy miova raha efa ao anatin'ny faritra ara-dalàna)
// ---------------------------------------------------------------------------
object VocalAnalyzer {
    /** Mamerina [mud(330 Hz), presence(4.2 kHz), air(10 kHz)] amin'ny dB. */
    fun suggest(s: Stereo): DoubleArray {
        val frame = SR / 20
        val nf = s.n / frame
        if (nf < 8) return doubleArrayOf(0.0, 0.0, 0.0)

        val fdb = DoubleArray(nf)
        var maxDb = -200.0
        for (f in 0 until nf) {
            var p = 0.0
            for (i in f * frame until (f + 1) * frame) {
                val m = 0.5 * (s.l[i] + s.r[i]); p += m * m
            }
            fdb[f] = 10 * log10(p / frame + 1e-12)
            if (fdb[f] > maxDb) maxDb = fdb[f]
        }

        val bands = arrayOf(
            Biquad.bandpass(330.0, 1.0) to 330.0,        // mud
            Biquad.bandpass(1700.0, 0.7) to 2429.0,      // afovoany (reference)
            Biquad.bandpass(4200.0, 0.9) to 4667.0,      // presence
            Biquad.bandpass(10500.0, 0.8) to 13125.0     // air
        )
        val e = DoubleArray(4)
        var cnt = 0L
        for (f in 0 until nf) {
            val active = fdb[f] > maxDb - 30
            for (i in f * frame until (f + 1) * frame) {
                val m = 0.5f * (s.l[i] + s.r[i])
                for (b in 0 until 4) {
                    val y = bands[b].first.process(m)
                    if (active) e[b] += (y * y).toDouble()
                }
            }
            if (active) cnt += frame
        }
        if (cnt == 0L) return doubleArrayOf(0.0, 0.0, 0.0)
        val d = DoubleArray(4) { 10 * log10(e[it] / cnt / bands[it].second + 1e-15) }

        val mudDev = (d[0] - d[1]) - 4.0          
        val presDev = (d[2] - d[1]) - (-9.0)
        val airDev = (d[3] - d[1]) - (-20.0)

        val mud = -((0.5 * (mudDev - 3.0)).coerceIn(0.0, 3.0))
        val pres = when {
            presDev > 3.0 -> -((0.5 * (presDev - 3.0)).coerceIn(0.0, 3.0))
            presDev < -3.0 -> (0.5 * (-presDev - 3.0)).coerceIn(0.0, 3.0)
            else -> 0.0
        }
        val air = if (airDev < -3.0) (0.5 * (-airDev - 3.0)).coerceIn(0.0, 3.0) else 0.0
        return doubleArrayOf(mud, pres, air)
    }
}
