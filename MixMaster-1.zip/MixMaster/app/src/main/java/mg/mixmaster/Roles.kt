package mg.mixmaster

import kotlin.math.log10
import kotlin.math.max

/**
 * Mamantatra ho azy izay feo (vocal) sy izay mozika (instrumental) rehefa voafidy ny fichier roa.
 * Mampiasa: (1) anaran'ny fichier, (2) bass, (3) fahanginana, (4) fahalehibiazan'ny stereo.
 * Mihodina (swap) raha mazava fa mifamadika. Raha tsy azo antoka dia tsy miova.
 */
object RoleDetector {

    class Features(val bassRatio: Double, val silenceFrac: Double, val sideRatio: Double)

    private val vocalWords = listOf("vocal", "voc", "voice", "voix", "acap", "feo", "vox", "chant", "sing")
    private val instWords = listOf("instru", "inst", "beat", "mozika", "music", "karaoke", "backing", "minus", "playback")

    /** +1 = vocal, -1 = instrumental, 0 = tsy fantatra. */
    fun nameHint(name: String): Int {
        val n = name.substringBeforeLast('.').lowercase()
        val v = vocalWords.any { n.contains(it) }
        val i = instWords.any { n.contains(it) }
        return when {
            v && !i -> 1
            i && !v -> -1
            else -> 0
        }
    }

    fun features(s: Stereo): Features {
        val lp1 = Biquad.lowpass(150.0)
        val lp2 = Biquad.lowpass(150.0)
        var eLow = 0.0
        var eAll = 0.0
        var eSide = 0.0
        val chunk = SR / 10
        val chunkDb = ArrayList<Double>()
        var acc = 0.0
        var cnt = 0
        for (i in 0 until s.n) {
            val m = 0.5f * (s.l[i] + s.r[i])
            val sd = 0.5f * (s.l[i] - s.r[i])
            val low = lp2.process(lp1.process(m))
            eLow += (low * low).toDouble()
            eAll += (m * m).toDouble()
            eSide += (sd * sd).toDouble()
            acc += (m * m).toDouble()
            if (++cnt == chunk) {
                chunkDb.add(10 * log10(acc / chunk + 1e-12))
                acc = 0.0
                cnt = 0
            }
        }
        val maxDb = chunkDb.maxOrNull() ?: -120.0
        val silence = if (chunkDb.isEmpty()) 0.0 else chunkDb.count { it < maxDb - 40 }.toDouble() / chunkDb.size
        return Features(eLow / (eAll + 1e-12), silence, eSide / (eAll + eSide + 1e-12))
    }

    /** true = ilay fichier 1 (A) dia mozika ary ny fichier 2 (B) dia feo: tokony hosoloina. */
    fun shouldSwap(nameA: String, nameB: String, a: Stereo, b: Stereo): Boolean {
        var swap = 0
        var keep = 0

        val ha = nameHint(nameA)
        val hb = nameHint(nameB)
        if (ha == -1 || hb == 1) swap += 2
        if (ha == 1 || hb == -1) keep += 2

        val fa = features(a)
        val fb = features(b)
        // bass: ny mozika no manana bass be kokoa
        if (fa.bassRatio > fb.bassRatio * 1.5 + 0.01) swap++
        else if (fb.bassRatio > fa.bassRatio * 1.5 + 0.01) keep++
        // fahanginana: ny feo no manana fitsaharana be kokoa
        if (fa.silenceFrac < fb.silenceFrac - 0.05) swap++
        else if (fa.silenceFrac > fb.silenceFrac + 0.05) keep++
        // stereo: ny mozika no malalaka kokoa, ny feo matetika eo afovoany
        if (fa.sideRatio > fb.sideRatio * 1.5 + 0.02) swap++
        else if (fb.sideRatio > fa.sideRatio * 1.5 + 0.02) keep++

        return swap > keep
    }
}
