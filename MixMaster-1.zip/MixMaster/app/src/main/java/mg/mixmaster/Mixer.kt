package mg.mixmaster

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/** Karazana mastering. Ny rehetra dia ho azy: tsy misy volume na reverb am-pelatanana. */
class Preset(
    val label: String,
    val targetLufs: Double,       // haavon'ny hira farany
    val reverb: Float,            // 0..1
    val vocalOffsetLu: Double,    // toeran'ny feo manoloana ny mozika (LU)
    val bassDb: Double,           // low shelf 100 Hz
    val airDb: Double,            // high shelf 9 kHz
    val glueRatio: Double,        // compressor ankapobeny
    val glueThrOffsetDb: Double,  // threshold = LUFS + offset
    val bandRatioScale: Double,   // 1.0 = compressor 3 band mahazatra
    val limiterReleaseMs: Double,
    val duckDepth: Float          // fampihenana ny mozika rehefa misy feo
) {
    companion object {
        /** Malefaka, voatahiry ny dynamique: mitovy amin'ny mastering "mahalala" mahazatra. */
        val NATUREL = Preset("Naturel", -14.0, 0.30f, 0.0, 0.5, 1.0, 1.5, 3.0, 0.8, 120.0, 0.15f)
        /** Mahomby amin'ny zavatra rehetra (streaming, finday, fiara). */
        val UNIVERSAL = Preset("Universal", -11.0, 0.40f, 1.0, 1.0, 1.5, 2.0, 2.0, 1.0, 80.0, 0.20f)
        /** Mahery sy haavo, mitazona ny limiter -1 dBFS. */
        val LOUD = Preset("Loud", -8.0, 0.35f, 1.5, 1.5, 2.0, 3.0, 0.0, 1.3, 50.0, 0.25f)
    }
}

class MixReport(val lufs: Double, val peakDb: Double, val seconds: Double)

object Mixer {

    private const val WORK_LUFS = -20.0

    // =====================================================================
    // FOMBA STEMS: feo (vocal) + mozika (instrumental) misaraka
    // =====================================================================
    fun process(
        voc: Stereo,
        inst: Stereo,
        p: Preset,
        report: (Int, String) -> Unit
    ): Pair<Stereo, MixReport> {

        // ---------------- 1. Feo: EQ ho azy, auto-level, de-esser, compressor ----------------
        report(5, "Manadio ny feo (EQ ho azy)...")
        EqChain { listOf(Biquad.highpass(80.0), Biquad.peaking(300.0, 1.0, -1.0)) }.process(voc)
        val adj = VocalAnalyzer.suggest(voc)
        EqChain {
            listOf(
                Biquad.peaking(330.0, 1.0, adj[0]),
                Biquad.peaking(4200.0, 0.9, 1.0 + adj[1]),
                Biquad.highShelf(10000.0, 1.5 + adj[2])
            )
        }.process(voc)

        report(12, "Mampitovy ny haavon'ny feo (auto-level)...")
        scale(voc, dbToLin(WORK_LUFS - Loudness.measure(voc.l, voc.r, voc.n)).toFloat())
        VocalRider().process(voc)

        report(18, "Mampihena ny \"s\" (de-esser)...")
        DeEsser().process(voc)

        report(22, "Compressor ny feo...")
        Compressor(thrDb = -22.0, ratio = 3.0, attackMs = 8.0, releaseMs = 120.0, kneeDb = 8.0).process(voc)

        // ---------------- 2. Mozika ----------------
        report(32, "Manadio ny mozika (EQ)...")
        EqChain { listOf(Biquad.highpass(25.0), Biquad.peaking(2800.0, 0.8, -1.5)) }.process(inst)

        // ---------------- 3. Fandanjalanjana ho azy ----------------
        report(40, "Mandanjalanja ho azy ny haavon'ny feo sy ny mozika...")
        val vocLufs = Loudness.measure(voc.l, voc.r, voc.n)
        val instLufs = Loudness.measure(inst.l, inst.r, inst.n)
        // ny faritra misy ny feo (200 Hz - 5 kHz) no refy: tsy ahosoran'ny bass lehibe ny toerana fitoerana
        val instMid = Loudness.measure(inst.l, inst.r, inst.n,
            pre = { listOf(Biquad.highpass(200.0), Biquad.lowpass(5000.0)) })
        val instShift = WORK_LUFS - instLufs
        val vocTarget = (instMid + instShift) + p.vocalOffsetLu
        val vg = dbToLin(vocTarget - vocLufs).toFloat()
        val ig = dbToLin(instShift).toFloat()

        // ---------------- 4. Mixing ----------------
        report(48, "Mamangaro feo + mozika sy reverb...")
        val tail = if (p.reverb > 0f) (SR * 2.5).toInt() else 0
        val total = max(inst.n, voc.n) + tail
        val mix: Stereo = if (inst.l.size >= total) inst else
            Stereo(inst.l.copyOf(total), inst.r.copyOf(total), inst.n)
        val oldN = inst.n

        val reverb = Reverb()
        val sendHp = Biquad.highpass(250.0)
        val sendLp = Biquad.lowpass(9000.0)
        val preDelay = FloatArray((SR * 0.020).toInt())
        var pi = 0
        val rg = p.reverb * 0.6f

        val ref = dbToLin(vocTarget).toFloat() * 2f
        val refInv = 1f / ref
        val ac = exp(-1.0 / (0.005 * SR)).toFloat()
        val rc = exp(-1.0 / (0.200 * SR)).toFloat()
        var env = 0f

        for (i in 0 until total) {
            var vl = 0f
            var vr = 0f
            if (i < voc.n) {
                vl = voc.l[i] * vg
                vr = voc.r[i] * vg
            }
            val a = max(abs(vl), abs(vr))
            env = if (a > env) ac * env + (1 - ac) * a else rc * env + (1 - rc) * a
            val dg = 1f - p.duckDepth * min(1f, env * refInv)

            var l = (if (i < oldN) mix.l[i] else 0f) * ig * dg + vl
            var r = (if (i < oldN) mix.r[i] else 0f) * ig * dg + vr

            if (rg > 0f) {
                var send = (vl + vr) * 0.5f
                send = sendLp.process(sendHp.process(send))
                val d = preDelay[pi]
                preDelay[pi] = send
                if (++pi >= preDelay.size) pi = 0
                reverb.process(d)
                l += reverb.outL * rg
                r += reverb.outR * rg
            }
            mix.l[i] = l
            mix.r[i] = r
        }
        mix.n = total
        voc.l = FloatArray(0); voc.r = FloatArray(0); voc.n = 0

        // ---------------- 5. Mastering ----------------
        report(62, "Mastering: EQ...")
        EqChain {
            listOf(
                Biquad.highpass(28.0),
                Biquad.lowShelf(100.0, p.bassDb),
                Biquad.peaking(250.0, 1.0, -1.0),
                Biquad.highShelf(9000.0, p.airDb)
            )
        }.process(mix)

        report(70, "Mastering: glue compressor...")
        val mixLufs = Loudness.measure(mix.l, mix.r, mix.n)
        Compressor(thrDb = mixLufs + p.glueThrOffsetDb, ratio = p.glueRatio, attackMs = 30.0, releaseMs = 180.0, kneeDb = 6.0)
            .process(mix)

        return Pair(mix, finish(mix, p, report))
    }

    // =====================================================================
    // FOMBA FICHIER MITAMBATRA (feo + mozika efa niara-nitambatra)
    // =====================================================================

    /** Crossover 3 band (LR4 @150 Hz sy @4 kHz), mitambatra tsara amin'ny fanalana. */
    private class Crossover3 {
        private val loL = arrayOf(Biquad.lowpass(150.0), Biquad.lowpass(150.0))
        private val loR = arrayOf(Biquad.lowpass(150.0), Biquad.lowpass(150.0))
        private val miL = arrayOf(Biquad.lowpass(4000.0), Biquad.lowpass(4000.0))
        private val miR = arrayOf(Biquad.lowpass(4000.0), Biquad.lowpass(4000.0))

        fun split(x: Stereo, low: Stereo, mid: Stereo, high: Stereo) {
            for (i in 0 until x.n) {
                val xl = x.l[i]
                val xr = x.r[i]
                val ll = loL[1].process(loL[0].process(xl))
                val lr = loR[1].process(loR[0].process(xr))
                val rl = xl - ll
                val rr = xr - lr
                val ml = miL[1].process(miL[0].process(rl))
                val mr = miR[1].process(miR[0].process(rr))
                low.l[i] = ll; low.r[i] = lr
                mid.l[i] = ml; mid.r[i] = mr
                high.l[i] = rl - ml; high.r[i] = rr - mr
            }
            low.n = x.n; mid.n = x.n; high.n = x.n
        }
    }

    private const val BLOCK = 8192

    private fun newBlock() = Stereo(FloatArray(BLOCK), FloatArray(BLOCK), 0)

    private fun copyBlock(src: Stereo, start: Int, len: Int, dst: Stereo) {
        System.arraycopy(src.l, start, dst.l, 0, len)
        System.arraycopy(src.r, start, dst.r, 0, len)
        dst.n = len
    }

    /** RMS (dB) ny band 3 (ambany/afovoany/ambony), tsy raharahaina ny fahanginana. */
    private fun bandLevels(src: Stereo): DoubleArray {
        val xo = Crossover3()
        val blk = newBlock(); val lo = newBlock(); val mi = newBlock(); val hi = newBlock()
        val sum = DoubleArray(3)
        var counted = 0L
        var start = 0
        while (start < src.n) {
            val len = min(BLOCK, src.n - start)
            copyBlock(src, start, len, blk)
            xo.split(blk, lo, mi, hi)
            val e = DoubleArray(3)
            for (i in 0 until len) {
                e[0] += (lo.l[i] * lo.l[i] + lo.r[i] * lo.r[i]).toDouble()
                e[1] += (mi.l[i] * mi.l[i] + mi.r[i] * mi.r[i]).toDouble()
                e[2] += (hi.l[i] * hi.l[i] + hi.r[i] * hi.r[i]).toDouble()
            }
            val total = (e[0] + e[1] + e[2]) / (2.0 * len)
            if (10 * log10(total + 1e-12) > -60.0) {
                for (b in 0 until 3) sum[b] += e[b]
                counted += len
            }
            start += len
        }
        return DoubleArray(3) { if (counted == 0L) -60.0 else 10 * log10(sum[it] / (2.0 * counted) + 1e-12) }
    }

    /**
     * Mastering ny fichier mitambatra: bass matanjaka sy madio (mono ambanin'ny 120 Hz),
     * fanalana ny fitaoman'ny 280 Hz, presence ho an'ny feo (eo afovoany), de-esser,
     * reverb malefaka avy amin'ny feo afovoany, compressor 3 band, ary limiter.
     */
    fun processMerged(
        src: Stereo,
        p: Preset,
        report: (Int, String) -> Unit
    ): Pair<Stereo, MixReport> {
        val tail = if (p.reverb > 0f) (SR * 2.5).toInt() else 0
        val total = src.n + tail
        val mix: Stereo = if (src.l.size >= total) src else
            Stereo(src.l.copyOf(total), src.r.copyOf(total), src.n)
        val srcN = src.n
        mix.n = srcN

        report(5, "Mandinika ny fifandanjalanjan'ny bass / afovoany / ambony...")
        val lv = bandLevels(mix)

        val pre = EqChain {
            listOf(
                Biquad.highpass(28.0),
                Biquad.lowShelf(90.0, p.bassDb + 0.5),
                Biquad.peaking(280.0, 1.0, -1.5)
            )
        }
        val sideHp = Biquad.highpass(120.0)
        val sideHp2 = Biquad.highpass(120.0)
        val presEq = Biquad.peaking(3200.0, 0.9, 1.5)
        val air = Biquad.highShelf(10000.0, p.airDb * 0.5)
        val deEss = DeEsser(thresholdRatio = 0.55, maxReductionDb = 5.0)
        val sendHp = Biquad.highpass(300.0)
        val sendLp = Biquad.lowpass(7000.0)
        val reverb = Reverb()
        val preDelay = FloatArray((SR * 0.020).toInt())
        var pi = 0
        val rg = p.reverb * 0.35f

        val xo = Crossover3()
        val k = p.bandRatioScale
        val compLow = Compressor(lv[0] + 1.0, 1.0 + 2.0 * k, 20.0, 120.0, 6.0)
        val compMid = Compressor(lv[1] + 3.0, 1.0 + 1.0 * k, 25.0, 150.0, 6.0)
        val compHigh = Compressor(lv[2] + 4.0, 1.0 + 1.0 * k, 15.0, 100.0, 6.0)

        val blk = newBlock(); val bLow = newBlock(); val bMid = newBlock(); val bHigh = newBlock()
        val mid = FloatArray(BLOCK); val side = FloatArray(BLOCK)
        val midS = Stereo(mid, mid, 0)

        var start = 0
        while (start < total) {
            report(10 + (60L * start / total).toInt(), "Mixing + mastering (EQ, de-esser, reverb, compressor)...")
            val len = min(BLOCK, total - start)
            copyBlock(mix, start, len, blk)
            pre.process(blk)

            for (i in 0 until len) {
                mid[i] = (blk.l[i] + blk.r[i]) * 0.5f
                side[i] = (blk.l[i] - blk.r[i]) * 0.5f
            }
            sideHp.processInPlace(side, len)
            sideHp2.processInPlace(side, len)
            presEq.processInPlace(mid, len)
            air.processInPlace(mid, len)
            midS.n = len
            deEss.process(midS)

            for (i in 0 until len) {
                var wl = 0f
                var wr = 0f
                if (rg > 0f) {
                    val send = sendLp.process(sendHp.process(mid[i]))
                    val d = preDelay[pi]
                    preDelay[pi] = send
                    if (++pi >= preDelay.size) pi = 0
                    reverb.process(d)
                    wl = reverb.outL * rg
                    wr = reverb.outR * rg
                }
                blk.l[i] = mid[i] + side[i] + wl
                blk.r[i] = mid[i] - side[i] + wr
            }

            xo.split(blk, bLow, bMid, bHigh)
            compLow.process(bLow)
            compMid.process(bMid)
            compHigh.process(bHigh)
            for (i in 0 until len) {
                blk.l[i] = bLow.l[i] + bMid.l[i] + bHigh.l[i]
                blk.r[i] = bLow.r[i] + bMid.r[i] + bHigh.r[i]
            }
            System.arraycopy(blk.l, 0, mix.l, start, len)
            System.arraycopy(blk.r, 0, mix.r, start, len)
            start += len
        }
        mix.n = total

        return Pair(mix, finish(mix, p, report))
    }

    // =====================================================================
    // Haavon'ny feo (LUFS) + limiter. Mamerina tatitra mba hanakaiky ny tanjona.
    // =====================================================================
    private fun finish(mix: Stereo, p: Preset, report: (Int, String) -> Unit): MixReport {
        report(80, "Mastering: haavon'ny feo (${p.label})...")
        var current = Loudness.measure(mix.l, mix.r, mix.n)
        scale(mix, dbToLin(min(p.targetLufs - current, 30.0)).toFloat())
        Limiter.process(mix, ceilingDb = -1.0, releaseMs = p.limiterReleaseMs)

        for (pass in 0 until 3) {
            report(86 + pass * 3, "Mastering: fanatsaran-dalana ${pass + 1}/3...")
            current = Loudness.measure(mix.l, mix.r, mix.n)
            val diff = p.targetLufs - current
            if (abs(diff) < 0.4) break
            scale(mix, dbToLin(min(diff, 6.0)).toFloat())
            Limiter.process(mix, ceilingDb = -1.0, releaseMs = p.limiterReleaseMs)
        }

        val finalLufs = Loudness.measure(mix.l, mix.r, mix.n)
        val peak = Loudness.peakDb(mix.l, mix.r, mix.n)
        report(100, "Vita!")
        return MixReport(finalLufs, peak, mix.n.toDouble() / SR)
    }

    private fun scale(s: Stereo, g: Float) {
        for (i in 0 until s.n) {
            s.l[i] *= g
            s.r[i] *= g
        }
    }

    /** Ho an'ny fampitahana: mampitovy ny haavon'ny [s] amin'ny [targetLufs] ary miaro ny peak -1 dBFS. */
    fun matchLoudness(s: Stereo, targetLufs: Double) {
        val cur = Loudness.measure(s.l, s.r, s.n)
        scale(s, dbToLin(min(targetLufs - cur, 30.0)).toFloat())
        if (Loudness.peakDb(s.l, s.r, s.n) > -1.0) Limiter.process(s, -1.0, 80.0)
    }
}
