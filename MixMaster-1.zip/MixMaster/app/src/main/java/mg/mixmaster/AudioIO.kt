package mg.mixmaster

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class AudioException(message: String) : Exception(message)

object AudioIO {

    /** Faharetany ambony indrindra (segondra) mba tsy hamoy ny memoria. */
    const val MAX_SECONDS = 8 * 60

    /** Frames fanampiny (zero) ao amin'ny faran'ny arrays: ho an'ny reverb tail. */
    const val TAIL_FRAMES = SR * 3

    // ------------------------------------------------------------------
    // DECODE: mp3 / aac / m4a / wav / flac / ogg ... -> float stereo 44.1 kHz
    // ------------------------------------------------------------------
    fun decode(ctx: Context, uri: Uri, progress: (Int) -> Unit): Stereo {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            try {
                extractor.setDataSource(ctx, uri, null)
            } catch (e: Exception) {
                throw AudioException("Tsy afaka nanokatra ny fichier: ${e.message}")
            }

            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) throw AudioException("Tsy misy lalana audio ao amin'io fichier io.")
            extractor.selectTrack(track)

            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            var sr = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else SR
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            if (durUs > MAX_SECONDS * 1_000_000L) {
                throw AudioException("Lava loatra ny fichier (mihoatra ny ${MAX_SECONDS / 60} minitra).")
            }
            var floatPcm = false

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()

            val estimate = if (durUs > 0) ((durUs / 1_000_000.0) * sr).toInt() + sr else sr * 180
            var l = FloatArray(estimate)
            var r = FloatArray(estimate)
            var n = 0
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val maxFrames = MAX_SECONDS * sr

            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                            if (durUs > 0) progress((60.0 * extractor.sampleTime / durUs).toInt().coerceIn(0, 60))
                        }
                    }
                }

                val oi = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        floatPcm = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                    oi >= 0 -> {
                        if (info.size > 0) {
                            val ob = codec.getOutputBuffer(oi)!!
                            ob.order(ByteOrder.LITTLE_ENDIAN)
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val safeCh = max(1, ch)
                            val frames: Int
                            if (floatPcm) {
                                val fb = ob.asFloatBuffer()
                                frames = fb.remaining() / safeCh
                                if (n + frames > l.size) {
                                    val ns = max((l.size * 1.25).toInt(), n + frames + sr)
                                    l = l.copyOf(ns); r = r.copyOf(ns)
                                }
                                for (f in 0 until frames) {
                                    val a = fb.get()
                                    val b = if (safeCh > 1) fb.get() else a
                                    for (k in 2 until safeCh) fb.get()
                                    l[n + f] = a; r[n + f] = b
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                frames = sb.remaining() / safeCh
                                if (n + frames > l.size) {
                                    val ns = max((l.size * 1.25).toInt(), n + frames + sr)
                                    l = l.copyOf(ns); r = r.copyOf(ns)
                                }
                                for (f in 0 until frames) {
                                    val a = sb.get() / 32768f
                                    val b = if (safeCh > 1) sb.get() / 32768f else a
                                    for (k in 2 until safeCh) sb.get()
                                    l[n + f] = a; r[n + f] = b
                                }
                            }
                            n += frames
                            if (n > maxFrames) throw AudioException("Lava loatra ny fichier (mihoatra ny ${MAX_SECONDS / 60} minitra).")
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }

            if (n == 0) throw AudioException("Tsy nahitana feo ao amin'ny fichier.")

            // Fanitsiana ho 44.1 kHz (interpolation linear) raha ilaina
            if (sr != SR) {
                val m = (n.toDouble() * SR / sr).toInt()
                val nl = FloatArray(m + TAIL_FRAMES)
                val nr = FloatArray(m + TAIL_FRAMES)
                val step = sr.toDouble() / SR
                for (i in 0 until m) {
                    val pos = i * step
                    val i0 = pos.toInt()
                    val fr = (pos - i0).toFloat()
                    val i1 = min(i0 + 1, n - 1)
                    nl[i] = l[i0] * (1 - fr) + l[i1] * fr
                    nr[i] = r[i0] * (1 - fr) + r[i1] * fr
                }
                return Stereo(nl, nr, m)
            }
            if (l.size < n + TAIL_FRAMES) {
                l = l.copyOf(n + TAIL_FRAMES)
                r = r.copyOf(n + TAIL_FRAMES)
            }
            return Stereo(l, r, n)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    // ------------------------------------------------------------------
    // WAV 16-bit stereo 44.1 kHz (miaraka amin'ny dither TPDF)
    // ------------------------------------------------------------------
    fun writeWav(out: OutputStream, s: Stereo, progress: (Int) -> Unit) {
        val dataSize = s.n.toLong() * 4
        if (dataSize + 36 > 0xFFFFFFFFL) throw AudioException("Lava loatra ho an'ny WAV.")
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt((36 + dataSize).toInt()); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(2)
        h.putInt(SR); h.putInt(SR * 4); h.putShort(4); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(dataSize.toInt())
        out.write(h.array())

        val rnd = Random(12345)
        val chunk = 16384
        val bb = ByteBuffer.allocate(chunk * 4).order(ByteOrder.LITTLE_ENDIAN)
        var i = 0
        while (i < s.n) {
            val len = min(chunk, s.n - i)
            bb.clear()
            for (k in 0 until len) {
                bb.putShort(toShort(s.l[i + k], rnd))
                bb.putShort(toShort(s.r[i + k], rnd))
            }
            out.write(bb.array(), 0, len * 4)
            i += len
            progress((100L * i / s.n).toInt())
        }
        out.flush()
    }

    private fun toShort(x: Float, rnd: Random?): Short {
        val d = if (rnd != null) (rnd.nextFloat() - rnd.nextFloat()) / 32768f else 0f
        return ((x + d) * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
    }

    /** PCM 16-bit interleaved ho an'ny AudioTrack (tsy misy dither). */
    fun toPcm16(s: Stereo, from: Int, len: Int, dst: ShortArray) {
        for (k in 0 until len) {
            dst[2 * k] = toShort(s.l[from + k], null)
            dst[2 * k + 1] = toShort(s.r[from + k], null)
        }
    }

    // ------------------------------------------------------------------
    // M4A (AAC-LC) amin'ny alalan'ny MediaCodec + MediaMuxer: tsy mila library
    // ------------------------------------------------------------------
    fun encodeAac(s: Stereo, outFile: File, bitrate: Int = 256_000, progress: (Int) -> Unit) {
        val mime = MediaFormat.MIMETYPE_AUDIO_AAC
        val fmt = MediaFormat.createAudioFormat(mime, SR, 2)
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)

        val codec = MediaCodec.createEncoderByType(mime)
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var track = -1
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        buf.clear()
                        buf.order(ByteOrder.LITTLE_ENDIAN)
                        val ptsUs = pos * 1_000_000L / SR
                        val cnt = min(buf.capacity() / 4, s.n - pos)
                        if (cnt <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            for (k in 0 until cnt) {
                                buf.putShort(toShort(s.l[pos + k], null))
                                buf.putShort(toShort(s.r[pos + k], null))
                            }
                            codec.queueInputBuffer(ii, 0, cnt * 4, ptsUs, 0)
                            pos += cnt
                            progress((100L * pos / s.n).toInt())
                        }
                    }
                }

                val oi = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && muxerStarted) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            muxer.writeSampleData(track, ob, info)
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }
}

/**
 * MP3: Android tsy manana encoder MP3 ao anatiny. Ampiasaina ny library LAME (TAndroidLame)
 * amin'ny alalan'ny reflection, mba tsy hiala ny build raha tsy misy ilay library.
 * Raha tsy misy: [isAvailable] = false ary ampiasaina ny M4A/WAV.
 */
object Mp3Export {
    private val packages = listOf("com.naman14.androidlame")

    private fun pkg(): String? = packages.firstOrNull {
        try { Class.forName("$it.AndroidLame"); Class.forName("$it.LameBuilder"); true } catch (_: Throwable) { false }
    }

    fun isAvailable(): Boolean = pkg() != null

    fun encode(s: Stereo, out: OutputStream, bitrateKbps: Int = 256, progress: (Int) -> Unit) {
        val p = pkg() ?: throw AudioException("Tsy ao anatin'ity APK ity ny encoder MP3. Ampiasao ny M4A na WAV.")
        val intT = Int::class.javaPrimitiveType!!
        val builderCls = Class.forName("$p.LameBuilder")
        val lameCls = Class.forName("$p.AndroidLame")
        var builder = builderCls.getDeclaredConstructor().newInstance()
        fun set(name: String, v: Int) {
            builder = builderCls.getMethod(name, intT).invoke(builder, v) ?: builder
        }
        set("setInSampleRate", SR)
        set("setOutSampleRate", SR)
        set("setOutChannels", 2)
        set("setOutBitrate", bitrateKbps)
        set("setQuality", 2)
        val lame = builderCls.getMethod("build").invoke(builder)
        val encode = lameCls.getMethod("encode", ShortArray::class.java, ShortArray::class.java, intT, ByteArray::class.java)
        // Ny anarana dia mety miovaova arakaraka ny fork: "flush" na "lameFlush"
        val flush = listOf("flush", "lameFlush").firstNotNullOfOrNull {
            try { lameCls.getMethod(it, ByteArray::class.java) } catch (_: NoSuchMethodException) { null }
        } ?: throw AudioException("Tsy mifanaraka ny API an'ny library MP3.")
        val close = lameCls.getMethod("close")

        try {
            val chunk = 8192
            val bl = ShortArray(chunk)
            val br = ShortArray(chunk)
            val mp3 = ByteArray((1.25 * chunk + 7200).toInt())
            var i = 0
            while (i < s.n) {
                val len = min(chunk, s.n - i)
                for (k in 0 until len) {
                    bl[k] = (s.l[i + k] * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
                    br[k] = (s.r[i + k] * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
                }
                val w = encode.invoke(lame, bl, br, len, mp3) as Int
                if (w < 0) throw AudioException("Hadisoana LAME ($w)")
                if (w > 0) out.write(mp3, 0, w)
                i += len
                progress((100L * i / s.n).toInt())
            }
            val w = flush.invoke(lame, mp3) as Int
            if (w > 0) out.write(mp3, 0, w)
            out.flush()
        } finally {
            try { close.invoke(lame) } catch (_: Throwable) {}
        }
    }
}
