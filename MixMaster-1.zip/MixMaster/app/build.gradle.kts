plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "mg.mixmaster"
    compileSdk = 34

    defaultConfig {
        applicationId = "mg.mixmaster"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // MP3 (LAME, GPLv3+): safidy. Alefaso: gradle assembleDebug -Pmp3Dep=com.github.naman14:TAndroidLame:1.1
    // Raha tsy omena ny -Pmp3Dep dia tsy ao anaty APK ny encoder MP3 (mbola azo atao ny WAV sy M4A).
    (project.findProperty("mp3Dep") as String?)?.let { implementation(it) }
}
