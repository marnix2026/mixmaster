import mg.mixmaster.*
import kotlin.math.*
import java.util.Random

fun synthVocal(sec: Double, phraseGainDb: (Int) -> Double = { 0.0 }, mud: Boolean = false): Stereo {
    val n = (sec * SR).toInt()
    val l = FloatArray(n + SR * 4); val r = FloatArray(n + SR * 4)
    val rnd = Random(1)
    val sib = Biquad.bandpass(7000.0, 1.0)
    val mudF = Biquad.peaking(330.0, 1.0, 10.0)
    var ph = 0.0
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val phrase = (t / 2.0).toInt()
        val syl = (sin(2 * PI * 2.2 * t) * 0.5 + 0.5).pow(1.5)
        val f0 = 220.0 + 40 * sin(2 * PI * 0.5 * t)
        ph += 2 * PI * f0 / SR
        var v = 0.0
        for (h in 1..12) v += sin(ph * h) / h * (if (h in 3..5) 1.5 else 1.0)
        v *= syl * 0.25 * 10.0.pow(phraseGainDb(phrase) / 20)
        val tm = t % 1.5
        val s = if (tm < 0.12) sib.process((rnd.nextFloat() - 0.5f) * 1.2f).toDouble() else 0.0
        var x = (v + s).toFloat()
        if (mud) x = mudF.process(x)
        l[i] = x; r[i] = x
    }
    return Stereo(l, r, n)
}

fun synthInst(sec: Double): Stereo {
    val n = (sec * SR).toInt()
    val l = FloatArray(n + SR * 4); val r = FloatArray(n + SR * 4)
    val rnd = Random(2)
    var bph = 0.0
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val beat = t % 0.5
        val kick = exp(-beat * 18) * sin(2 * PI * (50 + 80 * exp(-beat * 40)) * beat) * 0.8
        bph += 2 * PI * 55.0 / SR
        val bass = sin(bph) * 0.35 * (0.6 + 0.4 * exp(-beat * 4))
        val chord = (sin(2 * PI * 261.6 * t) + sin(2 * PI * 329.6 * t) + sin(2 * PI * 392.0 * t)) * 0.08
        val hat = if ((t % 0.25) < 0.03) (rnd.nextFloat() - 0.5) * 0.3 * exp(-(t % 0.25) * 90) else 0.0
        val wide = sin(2 * PI * 1200 * t + 0.5) * 0.03
        l[i] = (kick + bass + chord + hat + wide).toFloat()
        r[i] = (kick + bass + chord * 0.8 + hat * 1.2 - wide).toFloat()
    }
    return Stereo(l, r, n)
}

fun copy(s: Stereo) = Stereo(s.l.copyOf(), s.r.copyOf(), s.n)

fun check(name: String, s: Stereo, rep: MixReport, t0: Long, target: Double) {
    var nan = 0
    for (i in 0 until s.n) if (!s.l[i].isFinite() || !s.r[i].isFinite()) nan++
    val ms = System.currentTimeMillis() - t0
    println("[$name] ${"%.1f".format(s.n.toDouble() / SR)} s  LUFS=${"%.2f".format(rep.lufs)} (tanjona $target)  peak=${"%.2f".format(rep.peakDb)} dBFS  NaN=$nan  ${ms}ms")
}

fun lag(a: FloatArray, b: FloatArray, maxLag: Int): Int {
    val st = SR * 2; val len = SR * 4
    var best = 0; var bv = -1e30
    for (lg in -maxLag..maxLag) { var c = 0.0; for (i in 0 until len) c += a[st + i].toDouble() * b[st + i + lg]; if (c > bv) { bv = c; best = lg } }
    return best
}

fun phraseRmsSpread(x: FloatArray, sec: Int): Double {
    val levels = ArrayList<Double>()
    for (ph in 0 until sec / 2) {
        var p = 0.0; val a = ph * 2 * SR; val b = a + 2 * SR
        for (i in a until b) p += x[i].toDouble() * x[i]
        levels.add(10 * log10(p / (b - a) + 1e-12))
    }
    return levels.max() - levels.min()
}

fun main() {
    val sec = 30.0
    val presets = listOf(Preset.NATUREL, Preset.UNIVERSAL, Preset.LOUD)

    println("=== Fomba mitambatra ===")
    run {
        val v = synthVocal(sec); val inst = synthInst(sec)
        val mix = Stereo(FloatArray(v.l.size), FloatArray(v.l.size), v.n)
        for (i in 0 until v.n) { mix.l[i] = inst.l[i] + v.l[i]; mix.r[i] = inst.r[i] + v.r[i] }
        val orig = mix.l.copyOf()
        for (p in presets) {
            val t0 = System.currentTimeMillis()
            val (out, rep) = Mixer.processMerged(copy(mix), p) { _, _ -> }
            check("merged ${p.label}", out, rep, t0, p.targetLufs)
            if (p === Preset.UNIVERSAL) println("   lag = ${lag(orig, out.l, 400)} santionany")
        }
    }

    println("=== Fomba stems (feo + mozika) ===")
    for (p in presets) {
        val v = synthVocal(sec); val inst = synthInst(sec)
        val t0 = System.currentTimeMillis()
        val (out, rep) = Mixer.process(v, inst, p) { _, _ -> }
        check("stems ${p.label}", out, rep, t0, p.targetLufs)
    }

    println("=== Auto-level ny feo (phrase mahery/malemy) ===")
    run {
        val gains = doubleArrayOf(0.0, -10.0, -3.0, -12.0, 0.0, -8.0)  // dB isaky ny phrase 2 s
        val v = synthVocal(12.0, { gains[it % gains.size] })
        val before = phraseRmsSpread(v.l, 12)
        VocalRider().process(v)
        val after = phraseRmsSpread(v.l, 12)
        println("fanalavana haavo phrase (max-min): alohan'ny=${"%.1f".format(before)} dB, aorian'ny=${"%.1f".format(after)} dB")
    }

    println("=== EQ ho azy ny feo ===")
    run {
        val normal = synthVocal(12.0); val muddy = synthVocal(12.0, mud = true)
        println("feo mahazatra   -> mud/presence/air = ${VocalAnalyzer.suggest(normal).joinToString { "%.1f".format(it) }} dB")
        println("feo be fitaoman -> mud/presence/air = ${VocalAnalyzer.suggest(muddy).joinToString { "%.1f".format(it) }} dB")
    }

    println("=== Famantarana feo/mozika ===")
    run {
        val v = synthVocal(20.0); val inst = synthInst(20.0)
        println("OVER.m4a (mozika) = fichier 1, Vocal.m4a = fichier 2 -> swap=${RoleDetector.shouldSwap("OVER.m4a", "Vocal.m4a", inst, v)} (tokony true)")
        println("Vocal.m4a = fichier 1, OVER.m4a = fichier 2        -> swap=${RoleDetector.shouldSwap("Vocal.m4a", "OVER.m4a", v, inst)} (tokony false)")
        println("anarana tsy fantatra, mozika=1 feo=2 (features ihany) -> swap=${RoleDetector.shouldSwap("a.m4a", "b.m4a", inst, v)} (tokony true)")
        println("anarana tsy fantatra, feo=1 mozika=2 (features ihany) -> swap=${RoleDetector.shouldSwap("a.m4a", "b.m4a", v, inst)} (tokony false)")
    }

    println("=== Limiter / fahanginana ===")
    run {
        val n = SR * 5
        val s = Stereo(FloatArray(n) { (sin(it * 0.05) * 3.0).toFloat() }, FloatArray(n) { (sin(it * 0.031) * 4.0).toFloat() }, n)
        Limiter.process(s, -1.0)
        println("[limiter] peak aorian'ny = ${"%.3f".format(Loudness.peakDb(s.l, s.r, s.n))} dBFS (ceiling -1.0)")
        val z = Stereo(FloatArray(SR * 2), FloatArray(SR * 2), SR / 2)
        val (o, rep) = Mixer.processMerged(z, Preset.UNIVERSAL) { _, _ -> }
        println("[silence] LUFS=${rep.lufs} peak=${rep.peakDb} n=${o.n}")
    }
}
