# MixMaster (Android)

Rindrambaiko Android ho an'ny **mixing + mastering automatique**.

## Ho azy daholo
Tsy misy volume na reverb am-pelatanana. Safidio fichier, safidio preset (**Naturel**, **Universal**, **Loud**), dia tsindrio.
- Raha misy fichier roa (vocal + instrumental), hamantatra ho azy ny app izay feo sy izay mozika (anarana, bass, fahanginana, stereo).
- Vocal: EQ ho azy (manala fitaoman-peo, presence, air), auto-level (mampitovy ny phrase mahery/malemy), de-esser, compressor.
- Balance: ny feo dia apetraka ho azy manoloana ny mozika (araka ny faritra 200 Hz - 5 kHz).
- "Taloha" / "Vita": mampitaha amin'ny haavo mitovy, miaraka amin'ny toerana mitovy.

## Fomba roa
1. **Fichier mitambatra** (feo + mozika efa niara-nitambatra): safidio fichier iray ihany.
   Fanodinana: EQ (bass +, fanalana 280 Hz), bass mono ambanin'ny 120 Hz (bass matanjaka nefa madio),
   presence ho an'ny feo, de-esser, reverb malefaka, compressor 3 band, limiter -1 dBFS ary tanjona LUFS.
2. **Feo + mozika misaraka**: safidio ny fichier 2 (tsindrio maharitra eo amin'ny bokotra mba hanalana azy).
   Misy chain ho an'ny feo (EQ, de-esser, compressor, reverb), ducking kely ny mozika, ary mastering.

Tsy miova ny tononkira sy ny timing: tsy misy "pitch/time" processing; ny filtre dia IIR tsy misy latency
ary ny limiter dia mampiasa ny santionany mitovy index (lag voamarina = 0 santionany).

Fihainoana alohan'ny export (▶ Henoy). Export: **WAV** (16-bit), **M4A** (AAC 256 kbps) ary **MP3** (raha ao ny encoder).

## Hanao ny APK amin'ny GitHub Actions
1. Mamorona repository GitHub (ohatra `mixmaster`) ary ampidiro ny votoatin'ity lahatahiry ity (tsy ilaina ny zip: ny ao anaty `MixMaster/`).
2. Mandehana ao `Actions` > `Build APK` > `Run workflow` (na push amin'ny branch `main`).
3. Rehefa maitso, sintony ny APK:
   - `Releases` > `latest` > `MixMaster.apk`, na
   - rohy tsy miova: `https://github.com/<anaranao>/<repo>/releases/latest/download/MixMaster.apk`
4. Alefaso amin'ny finday ary ekeo ny "fametrahana avy amin'ny loharano tsy fantatra".

Ny APK dia **debug** (voasonia amin'ny fanalahidy debug), mety hapetraka mivantana. Ho an'ny Play Store dia mila signature "release".

## Hanao ny build an-toerana
Android Studio (Hedgehog+), JDK 17, Gradle 8.7: `gradle :app:assembleDebug`
(miaraka amin'ny MP3: `-Pmp3Dep=com.github.naman14:TAndroidLame:1.1`).

## MP3: fampitandremana
Android tsy manana encoder MP3. Ampiasaina ny TAndroidLame (LAME, **GPL v3+**). Raha zaraina publika ny APK
miaraka amin'io library io dia mila manaraka ny GPL (omena ny source). Raha tsy ilaina, esory ny `-Pmp3Dep`
ao amin'ny workflow: ny WAV sy M4A (AAC, kalitao mitovy na tsara kokoa ho an'ny habe mitovy) no mbola mandeha.

## Fetra
- Hira hatramin'ny 8 minitra (tsara indrindra < 5 minitra) noho ny memoria.
- Ny fichier mitambatra dia tsy azo sarahina ho feo/mozika (mila AI source-separation): ny mixing amin'ity fomba ity dia
  mampiasa ny fifandanjalanjan'ny band sy ny afovoany/sisiny (mid/side), fa tsy mamadika ny haavon'ny feo irery.
- `tools/DspTest.kt`: test DSP amin'ny JVM (kotlinc) ho an'ny developer.
